import asyncio

import pygame  # noqa: F401  (pygbag kijkt in main.py welke pakketten nodig zijn)

from spelletjes.main import hoofdlus

asyncio.run(hoofdlus())
