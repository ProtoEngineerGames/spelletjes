"""Dansfeest!

  links  = iedereen doet een nieuwe dans
  rechts = er komt een dansvriendje bij
  spatie = stopdans (muziek stopt, iedereen bevriest) - voor papa/mama
"""
import math
import random

import pygame

from . import common as c
from .common import W, H
from . import tosti

DANSEN = ["zwaaien", "springen", "wiebelen", "klappen", "draaien", "disco"]
SOORTEN = ["beer", "kat", "konijn", "tosti"]

HUID = (255, 214, 180)
HAAR = (120, 70, 40)
VACHT = {"meisje": HUID, "beer": (160, 110, 70), "kat": (250, 165, 75),
         "konijn": (238, 238, 245), "tosti": (120, 75, 35)}
LICHT = {"beer": (225, 190, 150), "kat": (255, 228, 195), "konijn": (255, 255, 255)}
OOR_BINNEN = (255, 170, 185)

BOVENARM, ONDERARM = 38, 36
BOVENBEEN, ONDERBEEN = 44, 44
BPM = 120
GROND = 615
PLEKKEN = [(390, 595, 0.85), (890, 595, 0.85), (200, 655, 1.0), (1080, 655, 1.0),
           (515, 560, 0.72), (765, 560, 0.72)]
BOX_L = pygame.Rect(20, 300, 110, 200)
BOX_R = pygame.Rect(W - 130, 300, 110, 200)


# ---------------------------------------------------------------- muziek

def freq(naam):
    noten = {"C": -9, "D": -7, "E": -5, "F": -4, "G": -2, "A": 0, "B": 2}
    return 440.0 * 2 ** ((noten[naam[0]] + 12 * (int(naam[1]) - 4)) / 12)


MELODIE = [
    "C5 E5 G5 E5 C5 E5 G5 -", "A4 C5 E5 C5 A4 C5 E5 -",
    "F4 A4 C5 A4 F4 A4 C5 D5", "B4 D5 G5 D5 B4 D5 G5 -",
    "C5 - G4 - C5 D5 E5 -", "E5 - C5 - A4 C5 E5 -",
    "F5 E5 D5 C5 A4 C5 D5 -", "B4 - G4 - B4 C5 D5 -",
]
BAS = ["C3", "A2", "F2", "G2", "C3", "A2", "F2", "G2"]

_muziek = None


def maak_muziek():
    """Een vrolijk dansdeuntje van 8 maten dat precies rond loopt."""
    global _muziek
    if _muziek is not None:
        return _muziek
    tel = 60 / BPM
    buf = c.leeg(len(MELODIE) * 4 * tel)
    for maat, (regel, bas) in enumerate(zip(MELODIE, BAS)):
        begin = maat * 4 * tel
        for i, noot in enumerate(regel.split()):
            if noot != "-":
                c.toon(buf, begin + i * tel / 2, tel * 0.7, freq(noot), 0.22, "zacht", 0.01, 1.5)
        for i in range(4):
            f = freq(bas) * (2 if i % 2 else 1)
            c.toon(buf, begin + i * tel, tel * 0.9, f, 0.32, "zacht", 0.01, 1.2)
            c.glijtoon(buf, begin + i * tel, 0.16, 150, 45, 0.7, 2)          # boem
            c.ruis(buf, begin + i * tel + tel / 2, 0.05, 0.12, 3)           # tsk
            if i % 2:
                c.ruis(buf, begin + i * tel, 0.12, 0.22, 3, 0.3)            # klap
    _muziek = c.geluid(buf, 0.6)
    return _muziek


# ---------------------------------------------------------------- dansjes

def pose(dans, b):
    """De houding van een danser op tel b (een kommagetal)."""
    w = math.sin(math.pi * b)
    stuit = abs(w)
    klap = abs(math.cos(math.pi * b))
    p = {"bob": 0.0, "tilt": 0.0, "shift": 0.0, "spin": 1.0, "la": 25.0, "le": 10.0, "ra": 25.0,
         "re": 10.0, "ll": 8.0, "lk": 0.0, "rl": 8.0, "rk": 0.0}
    naam = DANSEN[dans]
    if naam == "zwaaien":
        p.update(bob=-10 * stuit, tilt=7 * w, la=150 - 28 * w, le=-20 * w, ra=150 + 28 * w, re=20 * w,
                 lk=14 * (1 - stuit), rk=14 * (1 - stuit))
    elif naam == "springen":
        p.update(bob=-70 * stuit, la=35 + 125 * stuit, ra=35 + 125 * stuit, ll=6 + 18 * stuit,
                 rl=6 + 18 * stuit, lk=30 * (1 - stuit), rk=30 * (1 - stuit))
    elif naam == "wiebelen":
        p.update(bob=-6 * stuit, tilt=14 * w, shift=18 * w, la=45, le=-115, ra=45, re=-115,
                 lk=18 * max(0, w), rk=18 * max(0, -w))
    elif naam == "klappen":
        p.update(bob=-12 * klap, la=c.lerp(45, 15, klap), le=c.lerp(-50, -100, klap),
                 ra=c.lerp(45, 15, klap), re=c.lerp(-50, -100, klap), lk=12 * klap, rk=12 * klap)
    elif naam == "draaien":
        p.update(bob=-8 * stuit, spin=math.cos(math.pi * b / 2), la=95 + 12 * w, le=0, ra=95 - 12 * w, re=0,
                 ll=10, rl=10)
    elif naam == "disco":
        k = (w + 1) / 2
        p.update(bob=-6 * stuit, tilt=-8 * w, ra=50 + 115 * k, re=0, la=45, le=-115,
                 lk=22 * max(0, w), rk=22 * max(0, -w))
    return p


def _richting(hoek, kant):
    r = math.radians(hoek)
    return kant * math.sin(r), math.cos(r)


_tosti_lijf = {}


def tosti_lijf(voorkant):
    if voorkant not in _tosti_lijf:
        _tosti_lijf[voorkant] = tosti.maak_tosti(150, toast=0.6, kaas=True, gezicht=voorkant, seed=8)
    return _tosti_lijf[voorkant]


def teken_hoofd(surf, mid, r, spin, soort, kleur, voorkant, knipper):
    hx, hy = mid
    sx = abs(spin)

    def Q(dx, dy):
        return (hx + dx * r * spin, hy + dy * r)

    def ell(kl, dx, dy, rw, rh):
        x, y = Q(dx, dy)
        w = max(2, 2 * rw * r * sx)
        pygame.draw.ellipse(surf, kl, (x - w / 2, y - rh * r, w, 2 * rh * r))

    vacht = VACHT[soort]
    if soort == "beer":
        for k in (-1, 1):
            ell(vacht, k * 0.72, -0.72, 0.34, 0.34)
            ell(LICHT["beer"], k * 0.72, -0.72, 0.18, 0.18)
    elif soort == "kat":
        for k in (-1, 1):
            pygame.draw.polygon(surf, vacht, [Q(k * 0.92, -0.25), Q(k * 0.78, -1.25), Q(k * 0.18, -0.85)])
            pygame.draw.polygon(surf, OOR_BINNEN, [Q(k * 0.75, -0.45), Q(k * 0.72, -1.0), Q(k * 0.38, -0.8)])
    elif soort == "konijn":
        for k in (-1, 1):
            ell(vacht, k * 0.38, -1.3, 0.24, 0.7)
            ell(OOR_BINNEN, k * 0.38, -1.25, 0.11, 0.5)
    elif soort == "meisje":
        ell(HAAR, 0, -0.08, 1.1, 1.08)
        for k in (-1, 1):
            ell(HAAR, k * 1.18, 0.1, 0.38, 0.45)
            pygame.draw.polygon(surf, kleur, [Q(k * 0.95, -0.4), Q(k * 1.3, -0.65), Q(k * 1.3, -0.15)])

    ell(vacht, 0, 0, 1, 1)
    if soort == "meisje":
        if voorkant:
            ell(HAAR, 0, -0.68, 0.95, 0.42)
        else:
            ell(HAAR, 0, 0, 1.02, 1.02)

    if not voorkant or sx < 0.35:
        return
    if soort == "beer":
        ell(LICHT["beer"], 0, 0.4, 0.42, 0.3)
        ell(c.ZWART, 0, 0.27, 0.14, 0.1)
    elif soort == "kat":
        pygame.draw.polygon(surf, OOR_BINNEN, [Q(-0.1, 0.18), Q(0.1, 0.18), Q(0, 0.3)])
        for k in (-1, 1):
            for dy in (0.25, 0.42):
                pygame.draw.line(surf, c.ZWART, Q(k * 0.3, 0.33), Q(k * 0.95, dy), 2)
    elif soort == "konijn":
        ell(OOR_BINNEN, 0, 0.22, 0.1, 0.07)
        x, y = Q(0, 0.55)
        pygame.draw.rect(surf, c.WIT, (x - 8 * sx, y, 16 * sx, 12))
        pygame.draw.rect(surf, (200, 200, 210), (x - 8 * sx, y, 16 * sx, 12), 1)
    for k in (-1, 1):
        x, y = Q(k * 0.36, -0.08)
        if knipper:
            pygame.draw.line(surf, c.ZWART, (x - 7 * sx, y), (x + 7 * sx, y), 3)
        else:
            ell(c.ZWART, k * 0.36, -0.08, 0.11, 0.14)
            pygame.draw.circle(surf, c.WIT, (x - 3 * sx, y - 4), max(1, r * 0.05))
        ell(c.ROZE, k * 0.62, 0.25, 0.13, 0.09)
    mx, my = Q(0, 0.45)
    mw, mh = r * 0.5 * sx, r * 0.36
    pygame.draw.arc(surf, c.ZWART, (mx - mw / 2, my - mh / 2, max(2, mw), mh), math.pi, 2 * math.pi, 3)


def teken_danser(surf, x, grond, p, soort, kleur, S=1.0, knipper=False):
    """Teken een dansend figuurtje met de voeten op 'grond'."""
    spin = p["spin"]
    if abs(spin) < 0.22:
        spin = 0.22 if spin >= 0 else -0.22
    voorkant = spin > 0
    tilt = math.radians(p["tilt"])
    ct, st = math.cos(tilt), math.sin(tilt)

    heup_dx = 26 if soort == "tosti" else 16
    benen = []
    for kant, a, k in ((-1, p["ll"], p["lk"]), (1, p["rl"], p["rk"])):
        d1, d2 = _richting(a + k / 2, kant), _richting(a - k / 2, kant)
        knie = (kant * heup_dx + d1[0] * BOVENBEEN, d1[1] * BOVENBEEN)
        voet = (knie[0] + d2[0] * ONDERBEEN, knie[1] + d2[1] * ONDERBEEN)
        benen.append((kant, knie, voet))
    hoogte = max(b[2][1] for b in benen)
    heup_y = grond - (hoogte + 8) * S + p["bob"] * S

    def P(lx, ly):
        return (x + (lx + p["shift"]) * spin * S, heup_y + ly * S)

    def R(lx, ly):
        return P(lx * ct - ly * st, lx * st + ly * ct)

    dik = max(3, int(15 * S))
    ledemaat = VACHT[soort] if soort != "tosti" else VACHT["tosti"]
    if soort == "tosti":
        dik = max(3, int(9 * S))
    schoen = kleur if soort == "meisje" else c.mengkleur(VACHT[soort], c.ZWART, 0.35)

    # benen
    for kant, knie, voet in benen:
        h0, k1, v = P(kant * heup_dx, 0), P(*knie), P(*voet)
        c.lijn(surf, ledemaat, h0, k1, dik)
        c.lijn(surf, ledemaat, k1, v, dik)
        pygame.draw.ellipse(surf, schoen, (v[0] - 17 * S + kant * 7 * S * spin, v[1] - 7 * S, 34 * S, 16 * S))

    # lijf
    if soort == "tosti":
        img = tosti_lijf(voorkant)
        b = pygame.transform.smoothscale(img, (max(2, int(150 * abs(spin) * S)), int(150 * S)))
        b = pygame.transform.rotate(b, -p["tilt"])
        surf.blit(b, b.get_rect(center=R(0, -70)))
        schouder = (60, -70)
    elif soort == "meisje":
        pygame.draw.polygon(surf, kleur, [R(-22, -94), R(22, -94), R(52, 6), R(-52, 6)])
        pygame.draw.polygon(surf, c.mengkleur(kleur, c.WIT, 0.4), [R(-48, -6), R(48, -6), R(52, 6), R(-52, 6)])
        schouder = (26, -84)
    else:
        pts = [R(math.cos(a) * 36, -48 + math.sin(a) * 54) for a in (i * math.pi / 12 for i in range(24))]
        pygame.draw.polygon(surf, VACHT[soort], pts)
        pts = [R(math.cos(a) * 22, -40 + math.sin(a) * 34) for a in (i * math.pi / 12 for i in range(24))]
        pygame.draw.polygon(surf, LICHT[soort], pts)
        pygame.draw.polygon(surf, kleur, [R(-14, -96), R(14, -96), R(0, -84)])  # strikje
        schouder = (30, -82)

    # hoofd
    if soort != "tosti":
        teken_hoofd(surf, R(0, -134), 44 * S, spin, soort, kleur, voorkant, knipper)

    # armen
    hand = c.WIT if soort == "tosti" else ledemaat
    for kant, a, e in ((-1, p["la"], p["le"]), (1, p["ra"], p["re"])):
        sx, sy = kant * schouder[0], schouder[1]
        d1, d2 = _richting(a, kant), _richting(a + e, kant)
        el = (sx + d1[0] * BOVENARM, sy + d1[1] * BOVENARM)
        hd = (el[0] + d2[0] * ONDERARM, el[1] + d2[1] * ONDERARM)
        c.lijn(surf, ledemaat, R(sx, sy), R(*el), dik)
        c.lijn(surf, ledemaat, R(*el), R(*hd), dik)
        pygame.draw.circle(surf, hand, R(*hd), 11 * S)
        if soort == "tosti":
            pygame.draw.circle(surf, c.ZWART, R(*hd), 11 * S, 2)


class Danser:
    def __init__(self, soort, x, grond, schaal, kleur, dans=0):
        self.soort, self.x, self.grond, self.schaal, self.kleur = soort, x, grond, schaal, kleur
        self.dans = dans
        self.oud = None
        self.blend = 1.0
        self.verschijn = 0.0
        self.weg = None
        self.seed = random.uniform(0, 10)

    def pose(self, beat):
        p = pose(self.dans, beat)
        if self.oud is not None and self.blend < 1:
            k = c.ease_in_out(self.blend)
            p = {key: c.lerp(self.oud[key], p[key], k) for key in p}
        return p

    def wissel(self, beat, nieuw):
        self.oud = self.pose(beat)
        self.blend = 0.0
        self.dans = nieuw

    def update(self, dt):
        self.blend = min(1.0, self.blend + dt / 0.35)
        self.verschijn = min(1.0, self.verschijn + dt / 0.5)
        if self.weg is not None:
            self.weg += dt

    def draw(self, surf, beat):
        if self.weg is not None:
            k = 1 - c.ease_in(self.weg / 0.4)
        else:
            k = c.ease_out_back(self.verschijn)
        if k <= 0.02:
            return
        knipper = (beat * 0.37 + self.seed) % 4 < 0.08
        teken_danser(surf, self.x, self.grond, self.pose(beat), self.soort, self.kleur, self.schaal * k, knipper)


# ---------------------------------------------------------------- het spel

class DansSpel(c.Scene):
    def __init__(self):
        super().__init__()
        self.muziek = maak_muziek()
        self.kanaal = self.muziek.play(loops=-1)
        self.speelt = True
        self.beat = 0.0
        self.tijd = 0.0
        self.dans = 0
        self.hoofd = Danser("meisje", W // 2, GROND, 1.15, (255, 112, 166), self.dans)
        self.vrienden = []
        self.volgende_plek = 0
        self.vertrekkers = []
        self.deeltjes = c.Deeltjes()
        self.popups = c.Popups()
        self.overlay = pygame.Surface((W, H), pygame.SRCALPHA)
        self.kleur_i = 0
        self.vorige_tel = 0
        self.actief_l = self.actief_r = 0.0
        self.melding = None
        self.s_plop = c.plop(1.1)
        self.s_zoef = c.zoef()
        self.achtergrond = c.verloop((30, 15, 60), (95, 35, 120), (W, 560))

    def alle_dansers(self):
        return [self.hoofd] + self.vrienden

    def nieuwe_dans(self, nieuw=None):
        if nieuw is None:
            nieuw = (self.dans + random.randrange(1, len(DANSEN))) % len(DANSEN)
        self.dans = nieuw
        for d in self.alle_dansers():
            d.wissel(self.beat, nieuw)

    def nieuw_vriendje(self):
        x, grond, schaal = PLEKKEN[self.volgende_plek]
        for d in self.vrienden:
            if (d.x, d.grond) == (x, grond):
                d.weg = 0.0
                self.vertrekkers.append(d)
        self.vrienden = [d for d in self.vrienden if d.weg is None]
        soort = random.choice(SOORTEN)
        kleur = random.choice(c.FEEST)
        d = Danser(soort, x, grond, schaal, kleur, self.dans)
        self.vrienden.append(d)
        self.volgende_plek = (self.volgende_plek + 1) % len(PLEKKEN)
        self.s_plop.play()
        self.deeltjes.burst(x, grond - 120 * schaal, 30, snelheid=420, soort="ster", grootte=(8, 16))
        self.popups.voeg({"beer": "beer!", "kat": "poes!", "konijn": "konijn!", "tosti": "tosti!"}[soort],
                         x, grond - 300 * schaal, c.WIT, 50)

    def wissel_muziek(self):
        self.speelt = not self.speelt
        if self.kanaal is not None:
            if self.speelt:
                self.kanaal.unpause()
            else:
                self.kanaal.pause()
        self.melding = ["DANSEN!" if self.speelt else "STOP!", 0.0]

    def handle(self, e):
        k = c.toets(e)
        if k is None:
            return
        if e.key == pygame.K_SPACE:
            self.wissel_muziek()
            return
        if not self.speelt:
            self.wissel_muziek()
            return
        if k == "links":
            self.actief_l = 1.0
            self.nieuwe_dans()
            self.kleur_i += 1
            self.s_zoef.play()
            for box in (BOX_L, BOX_R):
                self.deeltjes.burst(box.centerx, box.top, 6, soort="noot", zwaartekracht=-60,
                                    snelheid=200, leven=2.0, grootte=(9, 13))
        elif k == "rechts":
            self.actief_r = 1.0
            self.nieuw_vriendje()
        else:
            self.nieuwe_dans()

    def update(self, dt):
        self.tijd += dt
        if self.speelt:
            self.beat += dt * BPM / 60
        tel = int(self.beat)
        if tel != self.vorige_tel:
            self.vorige_tel = tel
            if tel % 16 == 0:
                self.nieuwe_dans()
            box = random.choice((BOX_L, BOX_R))
            self.deeltjes.burst(box.centerx, box.top, 1, soort="noot", zwaartekracht=-60, snelheid=120,
                                leven=2.2, grootte=(9, 13), omhoog=1.0)
        for d in self.alle_dansers() + self.vertrekkers:
            d.update(dt)
        self.vertrekkers = [d for d in self.vertrekkers if d.weg < 0.5]
        self.actief_l = max(0.0, self.actief_l - dt * 4)
        self.actief_r = max(0.0, self.actief_r - dt * 4)
        if self.melding:
            self.melding[1] += dt
            if self.speelt and self.melding[1] > 1.2:
                self.melding = None
        self.deeltjes.update(dt)
        self.popups.update(dt)

    # ---------------------------------------------------------------- tekenen

    def teken_zaal(self, s):
        s.blit(self.achtergrond, (0, 0))
        b = self.beat
        # discobal
        pygame.draw.line(s, (200, 200, 210), (W // 2, 0), (W // 2, 40), 3)
        pygame.draw.circle(s, (200, 205, 220), (W // 2, 85), 45)
        for i in range(-3, 4):
            pygame.draw.line(s, (150, 155, 170), (W // 2 - 45, 85 + i * 12), (W // 2 + 45, 85 + i * 12), 1)
            xo = ((i * 12 + b * 10) % 84) - 42
            pygame.draw.line(s, (150, 155, 170), (W // 2 + xo, 42), (W // 2 + xo, 128), 1)
        for i in range(5):
            a = b * 1.3 + i * 1.3
            pygame.draw.polygon(s, c.WIT, c.sterpunten(W // 2 + math.cos(a) * 30, 85 + math.sin(a * 1.7) * 30, 7, 2, 4))
        # lichtbundels
        self.overlay.fill((0, 0, 0, 0))
        for i, bron in enumerate((160, W // 2, W - 160)):
            if not self.speelt:
                continue
            kleur = c.FEEST[(i + self.kleur_i) % len(c.FEEST)]
            a = math.sin(b * 0.5 + i * 2) * 0.6
            vx = bron + math.sin(a) * 700
            pygame.draw.polygon(self.overlay, (*kleur, 55), [(bron, 0), (vx - 110, H), (vx + 110, H)])
        s.blit(self.overlay, (0, 0))
        # vloer
        rijen = [540, 585, 640, H]
        for r in range(3):
            y0, y1 = rijen[r], rijen[r + 1]
            for k in range(-12, 12):
                def bx(y, k=k):
                    return W / 2 + k * (60 + (y - 540) * 0.9)
                aan = self.speelt and (k + r + int(b)) % 3 == 0
                kleur = c.FEEST[(k + r + self.kleur_i) % len(c.FEEST)] if aan else (50, 30, 75)
                pygame.draw.polygon(s, kleur, [(bx(y0), y0), (bx(y0, k + 1), y0), (bx(y1, k + 1), y1), (bx(y1), y1)])
                pygame.draw.polygon(s, (25, 15, 40), [(bx(y0), y0), (bx(y0, k + 1), y0), (bx(y1, k + 1), y1), (bx(y1), y1)], 2)
        # boxen
        boem = abs(math.cos(math.pi * b)) ** 4 if self.speelt else 0
        for box in (BOX_L, BOX_R):
            pygame.draw.rect(s, (35, 35, 45), box, border_radius=14)
            pygame.draw.rect(s, (90, 90, 110), box, 4, border_radius=14)
            pygame.draw.circle(s, (70, 70, 85), (box.centerx, box.top + 50), 24)
            pygame.draw.circle(s, (70, 70, 85), (box.centerx, box.bottom - 60), 36 + 6 * boem)
            pygame.draw.circle(s, (20, 20, 25), (box.centerx, box.bottom - 60), 14 + 4 * boem)

    def draw(self, s):
        self.teken_zaal(s)
        for d in sorted(self.alle_dansers() + self.vertrekkers, key=lambda d: d.grond):
            d.draw(s, self.beat)
        self.deeltjes.draw(s)
        self.popups.draw(s)
        bob = math.sin(self.tijd * 5) * 5
        c.pijl(s, (230, 70 + bob), -1, 42, actief=self.actief_l)
        c.pijl(s, (W - 230, 70 + bob), 1, 42, actief=self.actief_r)
        if self.melding:
            tekst, t = self.melding
            kleur = (255, 80, 80) if tekst == "STOP!" else (255, 220, 80)
            grootte = int(140 * c.ease_out_back(t / 0.3)) or 1
            c.tekst(s, tekst, grootte, kleur, (W // 2, 260), dikte=5)


if __name__ == "__main__":
    c.los_starten(DansSpel)
