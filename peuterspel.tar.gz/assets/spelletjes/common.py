"""Gedeelde hulpjes voor alle spelletjes: scherm, kleuren, geluid, confetti en tekst.

Alle spelletjes werken met alleen de pijltjestoetsen links en rechts.
Voor ouders: Esc = terug naar het menu, Ctrl+Q = stoppen.

Op een tablet (webversie) werkt aanraken ook: links op het scherm tikken = links,
rechts tikken = rechts, in het midden tikken = spatie. Het huisje bovenin even
vasthouden = terug naar het menu.
"""
import array
import asyncio
import functools
import math
import random
import sys
import time

import pygame

WEB = sys.platform == "emscripten"

W, H = 1280, 720
FPS = 60
RATE = 22050

FEEST = [(255, 89, 94), (255, 202, 58), (138, 201, 38), (25, 130, 196),
         (106, 76, 147), (255, 146, 76), (255, 112, 166), (78, 205, 196)]
WIT = (255, 255, 255)
ZWART = (30, 30, 40)
ROZE = (255, 150, 165)

LINKS = (pygame.K_LEFT, pygame.K_a)
RECHTS = (pygame.K_RIGHT, pygame.K_d)


# ---------------------------------------------------------------- rekenhulpjes

def lerp(a, b, t):
    return a + (b - a) * t


def klem(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def mengkleur(c1, c2, t):
    t = klem(t)
    return tuple(int(lerp(a, b, t)) for a, b in zip(c1, c2))


def ease_out(t):
    t = klem(t)
    return 1 - (1 - t) ** 3


def ease_in(t):
    t = klem(t)
    return t * t * t


def ease_in_out(t):
    t = klem(t)
    return t * t * (3 - 2 * t)


def ease_out_back(t):
    t = klem(t)
    c1 = 1.70158
    return 1 + (c1 + 1) * (t - 1) ** 3 + c1 * (t - 1) ** 2


def ease_out_bounce(t):
    t = klem(t)
    n, d = 7.5625, 2.75
    if t < 1 / d:
        return n * t * t
    if t < 2 / d:
        t -= 1.5 / d
        return n * t * t + 0.75
    if t < 2.5 / d:
        t -= 2.25 / d
        return n * t * t + 0.9375
    t -= 2.625 / d
    return n * t * t + 0.984375


def toets(e):
    """Geeft 'links', 'rechts', 'anders' of None terug voor een event."""
    if e.type != pygame.KEYDOWN:
        return None
    if e.key in LINKS:
        return "links"
    if e.key in RECHTS:
        return "rechts"
    return "anders"


# ---------------------------------------------------------------- scherm

def log(tekst):
    """Schrijf naar de console (in de browser: de JavaScript-console)."""
    if WEB:
        try:
            __import__("platform").window.console.log(tekst)
            return
        except Exception:
            pass
    print(tekst)


def start_scherm(titel="Spelletjes"):
    # in de browser een grotere buffer: dan hapert het geluid niet als een beeldje
    # even langer duurt (iets meer vertraging, dat merk je niet)
    pygame.mixer.pre_init(RATE, -16, 1, 2048 if WEB else 512, allowedchanges=0)
    pygame.init()
    flags = pygame.SCALED
    if "--venster" not in sys.argv and not WEB:
        flags |= pygame.FULLSCREEN
    scherm = pygame.display.set_mode((W, H), flags)
    pygame.display.set_caption(titel)
    pygame.mouse.set_visible(False)
    return scherm


class Stoppen(Exception):
    """Wordt gegooid als het hele programma moet stoppen."""


class Scene:
    """Basis voor een spelletje: handle / update / draw."""

    def __init__(self):
        self.klaar = False
        self.volgende = None

    def handle(self, e):
        pass

    def update(self, dt):
        pass

    def draw(self, s):
        pass

    def sluit(self):
        if pygame.mixer.get_init():
            pygame.mixer.stop()


# ---------------------------------------------------------------- aanraken (tablet)

_aanraak = {"zone": None, "gezien": False}
ZONE_TOETS = {"links": pygame.K_LEFT, "rechts": pygame.K_RIGHT, "midden": pygame.K_SPACE}
THUIS = pygame.Rect(W // 2 - 34, 6, 68, 60)     # huisje bovenin: vasthouden = terug naar het menu
THUIS_TIJD = 1.0


def aanraak_zone(x):
    if x < W * 0.35:
        return "links"
    if x > W * 0.65:
        return "rechts"
    return "midden"


def vast_links():
    """Wordt links nu vastgehouden (toets of vinger)?"""
    ingedrukt = pygame.key.get_pressed()
    return any(ingedrukt[k] for k in LINKS) or _aanraak["zone"] == "links"


def vast_rechts():
    ingedrukt = pygame.key.get_pressed()
    return any(ingedrukt[k] for k in RECHTS) or _aanraak["zone"] == "rechts"


def toets_event(key):
    return pygame.event.Event(pygame.KEYDOWN, key=key, mod=0, unicode="", scancode=0)


def teken_thuis(surf, t):
    """Klein huisje bovenin; t (0..1) = hoe lang het al wordt vastgehouden."""
    x, y = THUIS.center
    pygame.draw.circle(surf, (0, 0, 0), (x + 2, y + 3), 28)
    pygame.draw.circle(surf, (250, 250, 255), (x, y), 28)
    pygame.draw.polygon(surf, (90, 120, 200), [(x - 16, y - 1), (x, y - 15), (x + 16, y - 1)])
    pygame.draw.rect(surf, (90, 120, 200), (x - 11, y - 2, 22, 16))
    pygame.draw.rect(surf, (250, 250, 255), (x - 4, y + 5, 8, 9))
    if t:
        pygame.draw.arc(surf, (80, 200, 90), (x - 28, y - 28, 56, 56), math.pi / 2,
                        math.pi / 2 + klem(t) * 2 * math.pi, 7)


async def speel(scherm, scene, escape_mag=True):
    """Speel een scene tot hij klaar is. Esc gaat terug, Ctrl+Q stopt alles.

    Aanraken wordt omgezet in toetsen (links / midden = spatie / rechts), behalve
    als de scene zelf aanraken afhandelt (scene.aanraken = True)."""
    klok = pygame.time.Clock()
    thuis_t = None
    meet = [0, 0.0, 0.0, 0.0, pygame.time.get_ticks()]   # frames, update, draw, flip (ms)
    while not scene.klaar:
        dt = min(klok.tick(FPS) / 1000, 0.05)
        if WEB and pygame.time.get_ticks() - meet[4] > 5000 and meet[0]:
            n = meet[0]
            log(f"[meet] {type(scene).__name__} fps {n * 1000 / (pygame.time.get_ticks() - meet[4]):.0f}"
                  f" update {meet[1] / n:.1f} draw {meet[2] / n:.1f} flip {meet[3] / n:.1f} ms")
            meet = [0, 0.0, 0.0, 0.0, pygame.time.get_ticks()]
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                scene.sluit()
                raise Stoppen
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_q and (e.mod & pygame.KMOD_CTRL):
                    scene.sluit()
                    raise Stoppen
                if e.key == pygame.K_ESCAPE:
                    if escape_mag:
                        scene.sluit()
                        return None
                    continue
            if e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
                if getattr(scene, "aanraken", False):
                    scene.handle(e)
                elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                    _aanraak["gezien"] = True
                    if escape_mag and THUIS.inflate(30, 30).collidepoint(e.pos):
                        thuis_t = 0.0
                    else:
                        _aanraak["zone"] = aanraak_zone(e.pos[0])
                        scene.handle(toets_event(ZONE_TOETS[_aanraak["zone"]]))
                elif e.type == pygame.MOUSEBUTTONUP:
                    _aanraak["zone"] = None
                    thuis_t = None
                continue
            scene.handle(e)
        if thuis_t is not None:
            thuis_t += dt
            if thuis_t >= THUIS_TIJD:
                _aanraak["zone"] = None
                scene.sluit()
                return None
        t0 = time.perf_counter()
        scene.update(dt)
        t1 = time.perf_counter()
        scene.draw(scherm)
        if escape_mag and _aanraak["gezien"]:
            teken_thuis(scherm, (thuis_t or 0) / THUIS_TIJD)
        t2 = time.perf_counter()
        pygame.display.flip()
        t3 = time.perf_counter()
        meet[0] += 1
        meet[1] += (t1 - t0) * 1000
        meet[2] += (t2 - t1) * 1000
        meet[3] += (t3 - t2) * 1000
        await asyncio.sleep(0)
    _aanraak["zone"] = None
    scene.sluit()
    return scene.volgende


def los_starten(scene_cls):
    """Start één spelletje los (handig tijdens het maken)."""
    async def los():
        scherm = start_scherm()
        try:
            await speel(scherm, scene_cls())
        except Stoppen:
            pass
        pygame.quit()
    asyncio.run(los())


# ---------------------------------------------------------------- geluid

class _Stil:
    """Nep-geluid voor als er geen geluidskaart is."""

    def play(self, *a, **k):
        return None

    def stop(self):
        pass

    def set_volume(self, v):
        pass


def bewaard(maak):
    """Maak een geluid maar één keer (uitrekenen kost tijd, vooral in de browser)."""
    return functools.cache(maak)


def leeg(duur):
    return array.array("f", bytes(4 * int(duur * RATE)))


def geluid(buf, volume=1.0):
    """Maak een pygame Sound van een lijst samples (-1..1)."""
    stappen = geluid_stappen(buf, volume)
    while True:
        try:
            next(stappen)
        except StopIteration as klaar:
            return klaar.value


def geluid_stappen(buf, volume=1.0, stuk=20000):
    """Als geluid(), maar met een yield na elk stuk samples (gebruik: yield from)."""
    init = pygame.mixer.get_init()
    if not init:
        return _Stil()
    piek = 1.0
    for i in range(0, len(buf), stuk):
        piek = max(piek, max(map(abs, buf[i:i + stuk]), default=1.0))
        yield
    schaal = 30000 / piek
    data = array.array("h")
    for i in range(0, len(buf), stuk):
        data.extend(int(x * schaal) for x in buf[i:i + stuk])
        yield
    if init[2] == 2:
        stereo = array.array("h", bytes(len(data) * 4))
        stereo[0::2] = data
        stereo[1::2] = data
        data = stereo
    snd = pygame.mixer.Sound(buffer=data.tobytes())
    snd.set_volume(volume)
    return snd


def toon(buf, start, duur, freq, vol=0.3, golf="zacht", aanslag=0.01, verval=2.0):
    i0 = int(start * RATE)
    n = max(1, int(duur * RATE))
    att = max(1, int(aanslag * RATE))
    stap = 2 * math.pi * freq / RATE
    sin = math.sin
    for i in range(min(n, len(buf) - i0)):
        ph = stap * i
        if golf == "sinus":
            v = sin(ph)
        elif golf == "driehoek":
            f = (ph / (2 * math.pi)) % 1.0
            v = 4 * abs(f - 0.5) - 1
        else:  # zacht: sinus met een paar boventonen
            v = 0.7 * (sin(ph) + 0.35 * sin(2 * ph) + 0.15 * sin(3 * ph))
        env = (i / att if i < att else 1.0) * (1 - i / n) ** verval
        buf[i0 + i] += v * env * vol


def glijtoon(buf, start, duur, f0, f1, vol=0.4, verval=1.5, trilling=0.0):
    i0 = int(start * RATE)
    n = max(1, int(duur * RATE))
    ph = 0.0
    for i in range(min(n, len(buf) - i0)):
        t = i / n
        f = f0 + (f1 - f0) * t
        if trilling:
            f *= 1 + trilling * math.sin(2 * math.pi * 9 * i / RATE)
        ph += 2 * math.pi * f / RATE
        env = min(1.0, i / 60) * (1 - t) ** verval
        buf[i0 + i] += math.sin(ph) * env * vol


def ruis(buf, start, duur, vol=0.3, verval=3.0, zacht=0.0):
    i0 = int(start * RATE)
    n = max(1, int(duur * RATE))
    vorige = 0.0
    winst = math.sqrt((1 + zacht) / (1 - zacht)) if zacht < 1 else 1
    for i in range(min(n, len(buf) - i0)):
        vorige = vorige * zacht + random.uniform(-1, 1) * (1 - zacht)
        env = (1 - i / n) ** verval
        buf[i0 + i] += vorige * winst * env * vol


@bewaard
def plop(hoogte=1.0):
    buf = leeg(0.15)
    glijtoon(buf, 0, 0.13, 300 * hoogte, 950 * hoogte, 0.6, 2)
    return geluid(buf, 0.7)


@bewaard
def blip(freq=880):
    buf = leeg(0.12)
    toon(buf, 0, 0.12, freq, 0.5, "sinus", 0.003, 2)
    return geluid(buf, 0.5)


@bewaard
def pling():
    buf = leeg(0.35)
    toon(buf, 0, 0.35, 1568, 0.4, "sinus", 0.002, 3)
    toon(buf, 0.06, 0.29, 2093, 0.3, "sinus", 0.002, 3)
    return geluid(buf, 0.5)


@bewaard
def ding():
    buf = leeg(1.3)
    toon(buf, 0, 1.3, 1318, 0.4, "sinus", 0.002, 3)
    toon(buf, 0, 1.3, 1976, 0.2, "sinus", 0.002, 4)
    return geluid(buf, 0.7)


@bewaard
def blij_deuntje():
    buf = leeg(1.0)
    for i, f in enumerate((523, 659, 784, 1047)):
        toon(buf, i * 0.11, 0.5, f, 0.35, "zacht", 0.005, 2)
    return geluid(buf, 0.7)


@bewaard
def klap():
    buf = leeg(0.25)
    glijtoon(buf, 0, 0.22, 140, 45, 0.8, 2)
    ruis(buf, 0, 0.08, 0.3, 3, 0.5)
    return geluid(buf, 0.8)


@bewaard
def zoef():
    buf = leeg(0.5)
    n = len(buf)
    vorige = 0.0
    for i in range(n):
        t = i / n
        zacht = 0.95 - 0.6 * t
        vorige = vorige * zacht + random.uniform(-1, 1) * (1 - zacht)
        buf[i] = vorige * math.sin(math.pi * t) * 1.5
    return geluid(buf, 0.5)


@bewaard
def hap():
    buf = leeg(0.35)
    for s in (0.0, 0.15):
        ruis(buf, s, 0.1, 0.6, 2, 0.85)
        glijtoon(buf, s, 0.1, 220, 120, 0.4, 2)
    return geluid(buf, 0.8)


@bewaard
def sissen():
    buf = leeg(2.0)
    vorige = 0.0
    for i in range(len(buf)):
        r = random.uniform(-1, 1)
        buf[i] = (r - vorige) * 0.06
        vorige = r
    for _ in range(70):
        ruis(buf, random.uniform(0, 1.98), 0.01, 0.35, 4)
    return geluid(buf, 0.5)


# ---------------------------------------------------------------- tekenen

def sterpunten(cx, cy, r_buiten, r_binnen=None, punten=5, hoek=-90):
    if r_binnen is None:
        r_binnen = r_buiten * 0.45
    pts = []
    for i in range(punten * 2):
        r = r_buiten if i % 2 == 0 else r_binnen
        a = math.radians(hoek + i * 180 / punten)
        pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    return pts


def lijn(surf, kleur, a, b, dikte):
    """Dikke lijn met ronde uiteinden."""
    pygame.draw.line(surf, kleur, a, b, dikte)
    pygame.draw.circle(surf, kleur, a, dikte / 2)
    pygame.draw.circle(surf, kleur, b, dikte / 2)


def gezichtje(surf, cx, cy, maat, ogen_dicht=False):
    """Een schattig gezichtje: oogjes, wangetjes en een lach."""
    oog_r = max(2, maat * 0.09)
    for sx in (-1, 1):
        ox, oy = cx + sx * maat * 0.28, cy - maat * 0.1
        if ogen_dicht:
            pygame.draw.arc(surf, ZWART, (ox - oog_r * 1.3, oy - oog_r, oog_r * 2.6, oog_r * 2.4),
                            0, math.pi, max(2, int(oog_r * 0.6)))
        else:
            pygame.draw.circle(surf, ZWART, (ox, oy), oog_r)
            pygame.draw.circle(surf, WIT, (ox - oog_r * 0.3, oy - oog_r * 0.35), max(1, oog_r * 0.38))
        pygame.draw.circle(surf, ROZE, (cx + sx * maat * 0.42, cy + maat * 0.1), maat * 0.09)
    mw = maat * 0.32
    pygame.draw.arc(surf, ZWART, (cx - mw / 2, cy - mw * 0.3, mw, mw * 0.7),
                    math.pi, 2 * math.pi, max(2, int(maat * 0.05)))


SLEUTEL = (255, 0, 254)     # kleur die 'doorzichtig' betekent bij colorkey-plaatjes


def snel(surf):
    """Zet een plaatje om naar het formaat van het scherm (veel sneller blitten,
    vooral in de browser). Werkt alleen als het scherm er al is."""
    if pygame.display.get_surface() is None:
        return surf
    if surf.get_flags() & pygame.SRCALPHA:
        return surf.convert_alpha()
    return surf.convert()


def sleutel(surf, drempel=127):
    """Maak van een plaatje met alpha een plaatje met één doorzichtige kleur.
    Halfdoorzichtige randjes worden heel of weg. Dit is in de browser vele malen
    sneller dan alpha-blitten; gebruik het voor grote lagen zoals huizen en achtergronden."""
    if pygame.display.get_surface() is None or not surf.get_flags() & pygame.SRCALPHA:
        return snel(surf)
    masker = pygame.mask.from_surface(surf, drempel)
    vol = surf.copy()
    vol.fill((0, 0, 0, 255), special_flags=pygame.BLEND_RGBA_MAX)      # alles ondoorzichtig
    uit = pygame.Surface(surf.get_size()).convert()
    uit.blit(vol, (0, 0))
    masker.invert()
    masker.to_surface(uit, setcolor=SLEUTEL, unsetcolor=None)
    uit.set_colorkey(SLEUTEL, pygame.RLEACCEL)
    return uit


def laag(surf):
    """Grote achtergrondlaag: snij lege randen weg en maak er een colorkey-plaatje van.
    Geeft (plaatje, (dx, dy)) terug: blit op positie + (dx, dy)."""
    r = surf.get_bounding_rect()
    if r.width == 0:
        r = pygame.Rect(0, 0, 1, 1)
    return sleutel(surf.subsurface(r).copy()), r.topleft


_verlopen = {}


def verloop(c1, c2, size=(W, H)):
    key = (c1, c2, size)
    if key not in _verlopen:
        s = pygame.Surface(size)
        for y in range(size[1]):
            pygame.draw.line(s, mengkleur(c1, c2, y / max(1, size[1] - 1)), (0, y), (size[0], y))
        _verlopen[key] = snel(s)
    return _verlopen[key]


_fonts = {}


def lettertype(grootte):
    if grootte not in _fonts:
        _fonts[grootte] = pygame.font.SysFont("comicsansms,arialroundedmtbold,arial", grootte, bold=True)
    return _fonts[grootte]


_teksten = {}


def tekst_img(s, grootte, kleur, rand=ZWART, dikte=3):
    """Tekst met rand als één plaatje (wordt bewaard, want renderen is traag)."""
    key = (s, grootte, kleur, rand, dikte)
    img = _teksten.get(key)
    if img is None:
        if len(_teksten) > 400:
            _teksten.clear()
        f = lettertype(grootte)
        binnen = f.render(s, True, kleur)
        if rand:
            o = f.render(s, True, rand)
            img = pygame.Surface((binnen.get_width() + 2 * dikte, binnen.get_height() + 2 * dikte), pygame.SRCALPHA)
            for dx in (0, dikte, 2 * dikte):
                for dy in (0, dikte, 2 * dikte):
                    if dx != dikte or dy != dikte:
                        img.blit(o, (dx, dy))
            img.blit(binnen, (dikte, dikte))
        else:
            img = binnen
        img = snel(img)
        _teksten[key] = img
    return img


def tekst(surf, s, grootte, kleur, midden, rand=ZWART, dikte=3):
    img = tekst_img(s, grootte, kleur, rand, dikte)
    r = img.get_rect(center=(int(midden[0]), int(midden[1])))
    surf.blit(img, r)
    return r


def regenboogtekst(surf, s, grootte, midden, tijd):
    imgs = [tekst_img(ch, grootte, FEEST[i % len(FEEST)], ZWART, 4) for i, ch in enumerate(s)]
    x = midden[0] - sum(i.get_width() - 8 for i in imgs) / 2 - 4
    for i, img in enumerate(imgs):
        dy = math.sin(tijd * 4 + i * 0.6) * 8
        surf.blit(img, img.get_rect(midleft=(int(x), int(midden[1] + dy))))
        x += img.get_width() - 8


def pijl(surf, midden, richting, maat=50, kleur=(255, 202, 58), actief=0.0):
    """Grote pijl als hint voor de pijltjestoetsen. richting -1 = links, 1 = rechts.
    actief (0..1) laat de pijl even groter oplichten na een druk op de toets."""
    cx, cy = midden
    m = maat * (1 + 0.25 * actief)
    d = richting
    pts = [(cx + d * m, cy), (cx, cy - m * 0.9), (cx, cy - m * 0.4), (cx - d * m * 0.9, cy - m * 0.4),
           (cx - d * m * 0.9, cy + m * 0.4), (cx, cy + m * 0.4), (cx, cy + m * 0.9)]
    schaduw = [(x + 4, y + 6) for x, y in pts]
    pygame.draw.polygon(surf, (0, 0, 0), schaduw)
    pygame.draw.polygon(surf, mengkleur(kleur, WIT, actief * 0.6), pts)
    pygame.draw.polygon(surf, ZWART, pts, 4)


# ---------------------------------------------------------------- deeltjes

class _Deeltje:
    __slots__ = ("x", "y", "vx", "vy", "t", "leven", "kleur", "r", "soort", "hoek", "draai", "g")


class Deeltjes:
    """Confetti, sterretjes, muzieknootjes, kruimels en stoom."""

    def __init__(self):
        self.lijst = []

    def burst(self, x, y, n=24, kleuren=FEEST, snelheid=350, soort="confetti",
              zwaartekracht=700, leven=1.4, grootte=(7, 14), omhoog=0.35):
        for _ in range(n):
            d = _Deeltje()
            a = random.uniform(0, 2 * math.pi)
            s = snelheid * random.uniform(0.35, 1)
            d.x, d.y = x, y
            d.vx = math.cos(a) * s
            d.vy = math.sin(a) * s - snelheid * omhoog
            d.leven = leven * random.uniform(0.6, 1.0)
            d.t = d.leven
            d.kleur = random.choice(kleuren)
            d.r = random.uniform(*grootte)
            d.soort = soort
            d.hoek = random.uniform(0, 360)
            d.draai = random.uniform(-500, 500)
            d.g = zwaartekracht
            self.lijst.append(d)

    def update(self, dt):
        for d in self.lijst:
            d.vy += d.g * dt
            d.vx *= 1 - 0.8 * dt
            d.x += d.vx * dt
            d.y += d.vy * dt
            d.hoek += d.draai * dt
            d.t -= dt
        self.lijst = [d for d in self.lijst if d.t > 0 and -200 < d.y < H + 200]

    def draw(self, surf):
        for d in self.lijst:
            k = d.t / d.leven
            if d.soort == "confetti":
                a = math.radians(d.hoek)
                ca, sa = math.cos(a), math.sin(a)
                w, h = d.r, d.r * 0.5
                pts = [(d.x + ca * px - sa * py, d.y + sa * px + ca * py)
                       for px, py in ((-w, -h), (w, -h), (w, h), (-w, h))]
                pygame.draw.polygon(surf, d.kleur, pts)
            elif d.soort == "ster":
                r = d.r * min(1.0, k * 2)
                pygame.draw.polygon(surf, d.kleur, sterpunten(d.x, d.y, r, r * 0.45, 5, d.hoek))
            elif d.soort == "noot":
                r = d.r * min(1.0, k * 2)
                pygame.draw.ellipse(surf, d.kleur, (d.x - r, d.y - r * 0.7, r * 2, r * 1.4))
                pygame.draw.line(surf, d.kleur, (d.x + r * 0.8, d.y), (d.x + r * 0.8, d.y - r * 3.2), 4)
                pygame.draw.line(surf, d.kleur, (d.x + r * 0.8, d.y - r * 3.2), (d.x + r * 2, d.y - r * 2.2), 4)
            elif d.soort == "stoom":
                r = d.r * (1 + 1.5 * (1 - k)) * min(1.0, k * 3)
                pygame.draw.circle(surf, d.kleur, (d.x, d.y), r)
            elif d.soort == "kruimel":
                pygame.draw.rect(surf, d.kleur, (d.x, d.y, d.r, d.r * 0.8))
            else:
                pygame.draw.circle(surf, d.kleur, (d.x, d.y), d.r * min(1.0, k * 2))


class Popups:
    """Woordjes die even oppoppen, zoals 'Hap!' of 'Kaas!'."""

    def __init__(self):
        self.lijst = []

    def voeg(self, s, x, y, kleur=WIT, grootte=64, duur=1.2):
        # een nieuw woordje op dezelfde plek vervangt het oude
        self.lijst = [p for p in self.lijst if math.hypot(p[1] - x, p[2] - y) > 80]
        self.lijst.append([s, x, y, kleur, grootte, 0.0, duur])

    def update(self, dt):
        for p in self.lijst:
            p[5] += dt
        self.lijst = [p for p in self.lijst if p[5] < p[6]]

    def draw(self, surf):
        for s, x, y, kleur, grootte, t, duur in self.lijst:
            k = ease_out_back(t / 0.3)
            g = max(8, int(grootte * k))
            tekst(surf, s, g, kleur, (x, y - t * 60))
