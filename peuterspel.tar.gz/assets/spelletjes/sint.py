"""Sinterklaas: zoek het paard en de Pieten, en bezorg cadeautjes.

Het paard en een Piet hebben zich verstopt in de straat (staartje / baret steekt
uit). Gevonden Pieten lopen mee in de optocht (hooguit 3). Loopt Sint langs een
donker huis, dan springt een Piet uit de optocht het dak op en gooit een cadeautje
door de schoorsteen: het licht gaat aan en er staat een schoen voor de deur.
Alle huizen bezorgd = feest en een nieuwe nacht. Pieten rapen ook pepernoten op.
Een knipperende pijl wijst naar het dichtstbijzijnde doel.

  links  = Sinterklaas loopt naar links
  rechts = Sinterklaas loopt naar rechts
  spatie = springen (vangt vallende pepernoten) - extra, niet nodig
"""
import math
import random

import pygame

from . import common as c
from .common import W, H

WERELD = 4500
GROND = 612
SNELHEID = 330
MAX_OPTOCHT = 3
SPRONG_DUUR = 0.65
SPRONG_HOOGTE = 140

PAARD_WIT = (248, 248, 252)
PAARD_SCHADUW = (212, 212, 226)
MANEN = (185, 185, 205)
HOEF = (85, 85, 95)
SINT_ROOD = (200, 25, 40)
GOUD = (245, 195, 60)
HUID = (255, 210, 180)
PEPERNOOT = (170, 100, 50)


# ---------------------------------------------------------------- geluidjes

def hinniken():
    buf = c.leeg(1.0)
    c.glijtoon(buf, 0.0, 0.35, 900, 1500, 0.4, 0.5, trilling=0.06)
    c.glijtoon(buf, 0.3, 0.6, 1400, 500, 0.45, 1.2, trilling=0.1)
    c.toon(buf, 0.0, 0.9, 300, 0.15, "zacht", 0.05, 1.5)
    return c.geluid(buf, 0.6)


def hoefje(hoog):
    buf = c.leeg(0.08)
    c.toon(buf, 0, 0.05, 1100 if hoog else 800, 0.5, "sinus", 0.001, 4)
    c.ruis(buf, 0, 0.03, 0.3, 4, 0.3)
    return c.geluid(buf, 0.5)


def boing():
    buf = c.leeg(0.35)
    c.glijtoon(buf, 0.0, 0.3, 250, 900, 0.5, 1.0)
    return c.geluid(buf, 0.5)


def hoi():
    buf = c.leeg(0.4)
    c.glijtoon(buf, 0.0, 0.15, 500, 750, 0.4, 0.8)
    c.glijtoon(buf, 0.15, 0.22, 750, 1000, 0.4, 1.2)
    return c.geluid(buf, 0.5)


def fanfare():
    buf = c.leeg(1.6)
    for i, (f, d) in enumerate(((392, 0.15), (523, 0.15), (659, 0.15), (784, 0.3), (659, 0.15), (784, 0.6))):
        start = sum(x[1] for x in ((392, 0.15), (523, 0.15), (659, 0.15), (784, 0.3), (659, 0.15))[:i])
        c.toon(buf, start, d + 0.25, f, 0.35, "zacht", 0.005, 1.5)
    return c.geluid(buf, 0.7)


# ---------------------------------------------------------------- tekenen

def teken_paard(surf, x, grond, richting, fase, rennen, tijd):
    """Het witte paard van opzij. richting 1 = kijkt naar rechts."""
    def P(lx, ly):
        return (x + lx * richting, grond + ly)

    def ell(kleur, cx, cy, rx, ry, rot=0.0):
        cr, sr = math.cos(rot), math.sin(rot)
        pts = []
        for i in range(24):
            a = i * 2 * math.pi / 24
            px, py = math.cos(a) * rx, math.sin(a) * ry
            pts.append(P(cx + px * cr - py * sr, cy + px * sr + py * cr))
        pygame.draw.polygon(surf, kleur, pts)

    # staart
    zwaai = 10 + (20 if rennen else 0)
    for i in range(9):
        t = i / 8
        tx = -86 - t * 40 + math.sin(tijd * 6 + t * 2.5) * zwaai * t
        ty = -130 + t * 75 - (25 * t if rennen else 0)
        pygame.draw.circle(surf, MANEN, P(tx, ty), 15 - t * 5)

    # benen: eerst de twee achterste (donkerder), dan de voorste
    swing_max = 0.65 if rennen else 0.05
    for hx, off, kleur in ((-48, 0.0, PAARD_SCHADUW), (42, math.pi, PAARD_SCHADUW),
                           (-62, math.pi, PAARD_WIT), (56, 0.0, PAARD_WIT)):
        swing = math.sin(fase + off) * swing_max
        heup = P(hx, -92)
        knie_l = (hx + math.sin(swing) * 44, -92 + math.cos(swing) * 44)
        onder = swing - abs(swing) * 0.9
        voet_l = (knie_l[0] + math.sin(onder) * 46, knie_l[1] + math.cos(onder) * 46)
        voet_l = (voet_l[0], min(voet_l[1], 0))
        c.lijn(surf, kleur, heup, P(*knie_l), 18)
        c.lijn(surf, kleur, P(*knie_l), P(*voet_l), 16)
        hx2, hy2 = P(*voet_l)
        pygame.draw.rect(surf, HOEF, (hx2 - 10, hy2 - 8, 20, 12), border_radius=3)

    # lijf, dekje, nek en hoofd
    ell(PAARD_WIT, 0, -112, 90, 46)
    pygame.draw.polygon(surf, SINT_ROOD, [P(-38, -154), P(30, -154), P(36, -102), P(-44, -102)])
    pygame.draw.line(surf, GOUD, P(-44, -104), P(36, -104), 5)
    pygame.draw.polygon(surf, PAARD_WIT, [P(42, -140), P(80, -108), P(122, -186), P(90, -208)])
    for i in range(7):
        t = i / 6
        pygame.draw.circle(surf, MANEN, P(c.lerp(40, 90, t) - 4, c.lerp(-140, -214, t) + 2), 11)
    ell(PAARD_WIT, 130, -192, 48, 25, 0.5)
    ell(PAARD_SCHADUW, 160, -170, 19, 17)
    pygame.draw.circle(surf, HOEF, P(168, -168), 4)
    pygame.draw.polygon(surf, PAARD_WIT, [P(96, -212), P(104, -244), P(116, -210)])
    pygame.draw.polygon(surf, c.ROZE, [P(101, -214), P(105, -234), P(111, -213)])
    oog = P(122, -200)
    pygame.draw.circle(surf, c.ZWART, oog, 6)
    pygame.draw.circle(surf, c.WIT, (oog[0] + 2 * richting, oog[1] - 2), 2)
    pygame.draw.circle(surf, c.ROZE, P(140, -184), 6)


PIET_PAKKEN = [((240, 120, 30), (60, 70, 210)), ((40, 170, 90), (245, 200, 40)),
               ((150, 60, 200), (255, 140, 190)), ((30, 150, 220), (250, 90, 60)),
               ((230, 60, 140), (70, 200, 200)), ((250, 200, 40), (200, 40, 60))]
PIET_HUID = [(255, 218, 190), (240, 195, 160), (225, 175, 135)]
ROET = (95, 95, 105)
PIET_HAAR = (95, 60, 35)


def teken_piet(surf, x, grond, pak, huid, richting=1, fase=0.0, lopen=False, armen_omhoog=False, S=1.0):
    """Een vrolijke roetveegpiet met baret en veer. Voeten op 'grond'."""
    kleur1, kleur2 = pak

    def P(lx, ly):
        return (x + lx * richting * S, grond + ly * S)

    def ell(kleur, cx, cy, rx, ry):
        px, py = P(cx, cy)
        pygame.draw.ellipse(surf, kleur, (px - rx * S, py - ry * S, 2 * rx * S, 2 * ry * S))

    swing = math.sin(fase) if lopen else 0.0
    dik = max(3, int(12 * S))
    # benen
    for kant in (-1, 1):
        voet = (kant * 12 + swing * 16 * kant, 0)
        c.lijn(surf, kleur2, P(kant * 12, -60), P(*voet), dik)
        ell(c.ZWART, voet[0] + 6, -5, 15, 7)
    # lijf: pofbroek en wambuis
    ell(kleur2, 0, -66, 30, 16)
    ell(kleur1, 0, -92, 34, 30)
    ell(kleur2, 0, -92, 11, 28)
    # armen
    for kant in (-1, 1):
        schouder = (kant * 28, -108)
        if armen_omhoog:
            hand = (kant * 30, -170 + math.sin(fase + kant) * 6)
        else:
            hand = (kant * 36 - swing * 14 * kant, -68)
        c.lijn(surf, kleur1, P(*schouder), P(*hand), max(3, int(11 * S)))
        pygame.draw.circle(surf, c.WIT, P(*hand), 8 * S)
    # molensteenkraag
    for i in range(7):
        ell(c.WIT, -27 + i * 9, -117, 7, 7)
    # hoofd
    for hx, hy in ((-22, -150), (-25, -136), (-16, -128), (22, -150), (25, -136)):
        ell(PIET_HAAR, hx, hy, 10, 10)
    ell(huid, 0, -143, 27, 27)
    for rx, ry, w, h in ((13, -131, 6, 4), (-12, -158, 5, 3), (-17, -137, 4, 3)):   # roetvegen
        ell(ROET, rx, ry, w, h)
    for kant in (-1, 1):
        ox, oy = P(kant * 9, -147)
        pygame.draw.circle(surf, c.ZWART, (ox, oy), 3.5 * S)
        pygame.draw.circle(surf, c.WIT, (ox - 1, oy - 1.5), 1.3 * S)
        ell(c.ROZE, kant * 17, -137, 5, 3.5)
    mx, my = P(0, -134)
    pygame.draw.arc(surf, c.ZWART, (mx - 9 * S, my - 5 * S, 18 * S, 11 * S), math.pi, 2 * math.pi, max(2, int(2.5 * S)))
    # baret met veer
    ell(kleur2, 5, -166, 31, 11)
    ell(kleur2, 2, -172, 18, 8)
    veer = [P(16, -170), P(26, -186), P(40, -198), P(56, -202)]
    pygame.draw.lines(surf, c.WIT, False, veer, max(3, int(7 * S)))


def maak_sint():
    """Sinterklaas van opzij (kijkt naar rechts), zonder voetjes."""
    s = pygame.Surface((230, 360), pygame.SRCALPHA)
    # staf
    pygame.draw.line(s, GOUD, (188, 60), (188, 350), 8)
    pygame.draw.circle(s, GOUD, (172, 60), 18, 7, draw_top_left=True, draw_top_right=True)
    pygame.draw.circle(s, GOUD, (158, 62), 6)
    # mantel en kleed
    pygame.draw.polygon(s, SINT_ROOD, [(62, 150), (150, 150), (192, 345), (28, 345)])
    pygame.draw.polygon(s, c.WIT, [(112, 165), (142, 165), (168, 345), (118, 345)])
    pygame.draw.line(s, GOUD, (112, 165), (118, 345), 6)
    pygame.draw.line(s, GOUD, (28, 343), (192, 343), 6)
    # mouw en hand
    pygame.draw.polygon(s, SINT_ROOD, [(95, 170), (130, 160), (182, 222), (160, 240)])
    pygame.draw.circle(s, c.WIT, (184, 232), 14)
    # hoofd en baard
    pygame.draw.circle(s, HUID, (112, 112), 40)
    pygame.draw.ellipse(s, c.WIT, (70, 112, 92, 120))
    pygame.draw.ellipse(s, c.WIT, (110, 112, 50, 26))
    pygame.draw.circle(s, (240, 150, 140), (150, 108), 10)
    pygame.draw.circle(s, c.ZWART, (132, 96), 5)
    pygame.draw.arc(s, c.WIT, (122, 82, 22, 12), 0, math.pi, 4)
    pygame.draw.circle(s, c.ROZE, (138, 118), 7)
    # mijter
    mijter = [(70, 88), (156, 88), (148, 28), (113, 0), (78, 28)]
    pygame.draw.polygon(s, SINT_ROOD, mijter)
    pygame.draw.polygon(s, GOUD, mijter, 5)
    pygame.draw.rect(s, GOUD, (72, 72, 82, 12))
    pygame.draw.rect(s, GOUD, (107, 22, 12, 40))
    pygame.draw.rect(s, GOUD, (96, 34, 34, 11))
    return s


def obj_huis(licht=True):
    s = pygame.Surface((300, 345), pygame.SRCALPHA)
    pygame.draw.rect(s, (210, 40, 40), (200, 20, 42, 90))
    pygame.draw.rect(s, (170, 85, 60), (10, 125, 280, 220))
    for y in range(140, 345, 22):
        pygame.draw.line(s, (150, 70, 50), (10, y), (290, y), 2)
    pygame.draw.polygon(s, (60, 55, 75), [(0, 132), (150, 15), (300, 132)])
    for wx in (35, 195):
        pygame.draw.rect(s, (255, 220, 110) if licht else (35, 45, 85), (wx, 170, 70, 62))
        pygame.draw.rect(s, c.WIT, (wx, 170, 70, 62), 5)
        pygame.draw.line(s, c.WIT, (wx + 35, 170), (wx + 35, 232), 4)
        pygame.draw.line(s, c.WIT, (wx, 201), (wx + 70, 201), 4)
    pygame.draw.rect(s, (110, 60, 40), (122, 255, 56, 90), border_top_left_radius=26, border_top_right_radius=26)
    pygame.draw.circle(s, GOUD, (168, 300), 5)
    return s


def obj_boom():
    s = pygame.Surface((310, 360), pygame.SRCALPHA)
    pygame.draw.rect(s, (110, 70, 40), (138, 300, 34, 60))
    for i, (w, y) in enumerate(((310, 300), (250, 210), (180, 120))):
        pygame.draw.polygon(s, (40 + i * 15, 130 + i * 15, 70), [(155 - w / 2, y), (155, y - 150), (155 + w / 2, y)])
    pygame.draw.polygon(s, (60, 165, 90), [(155, 0), (110, 80), (200, 80)])
    return s


def obj_cadeaus():
    s = pygame.Surface((320, 270), pygame.SRCALPHA)
    for (x, y, w, h), kleur, lint in (((10, 110, 180, 160), (230, 60, 70), (255, 215, 60)),
                                      ((175, 150, 140, 120), (60, 130, 230), c.WIT),
                                      ((50, 20, 120, 92), (80, 190, 100), (255, 140, 190))):
        pygame.draw.rect(s, kleur, (x, y, w, h), border_radius=8)
        pygame.draw.rect(s, lint, (x + w / 2 - 9, y, 18, h))
        pygame.draw.rect(s, lint, (x, y + h / 2 - 9, w, 18))
    for k in (-1, 1):
        pygame.draw.ellipse(s, (255, 140, 190), (110 + k * 22 - 18, 2, 36, 24))
    return s


def obj_haag():
    s = pygame.Surface((330, 255), pygame.SRCALPHA)
    pygame.draw.rect(s, (50, 140, 70), (0, 20, 330, 235), border_radius=60)
    rng = random.Random(2)
    for _ in range(45):
        pygame.draw.circle(s, (70, 165, 85), (rng.uniform(25, 305), rng.uniform(45, 235)), rng.uniform(12, 24))
    for _ in range(8):
        pygame.draw.circle(s, (255, 120, 160), (rng.uniform(25, 305), rng.uniform(45, 235)), 7)
    return s


def obj_zak():
    s = pygame.Surface((300, 270), pygame.SRCALPHA)
    pygame.draw.ellipse(s, (160, 40, 50), (10, 60, 280, 210))
    pygame.draw.polygon(s, (160, 40, 50), [(100, 80), (200, 80), (180, 20), (120, 20)])
    pygame.draw.rect(s, GOUD, (112, 62, 76, 14), border_radius=6)
    pygame.draw.rect(s, (60, 130, 230), (120, 0, 34, 30))
    pygame.draw.rect(s, (255, 215, 60), (150, 6, 30, 26))
    pygame.draw.ellipse(s, (190, 70, 80), (50, 110, 60, 90))
    return s


OBJECTEN = [obj_huis, obj_boom, obj_cadeaus, obj_haag, obj_zak]


def maak_lucht():
    s = c.verloop((10, 15, 50), (50, 60, 120), (W, H)).copy()
    rng = random.Random(11)
    for _ in range(90):
        pygame.draw.circle(s, (255, 255, 220), (rng.uniform(0, W), rng.uniform(0, 420)), rng.uniform(1, 2.5))
    pygame.draw.circle(s, (255, 245, 200), (1060, 110), 60)
    pygame.draw.circle(s, (20, 28, 70), (1088, 92), 54)
    return s


def maak_daken():
    breedte = int((WERELD - W) * 0.4) + W
    s = pygame.Surface((breedte, H), pygame.SRCALPHA)
    rng = random.Random(5)
    x = -20
    while x < breedte:
        w = rng.randint(110, 190)
        h = rng.randint(150, 260)
        kleur = (35, 35, 70)
        pygame.draw.rect(s, kleur, (x, GROND - 60 - h, w, h + 60))
        if rng.random() < 0.6:
            pygame.draw.polygon(s, kleur, [(x, GROND - 60 - h), (x + w / 2, GROND - 60 - h - 60), (x + w, GROND - 60 - h)])
        pygame.draw.rect(s, kleur, (x + w * 0.65, GROND - 60 - h - 50, 22, 50))
        for wy in range(GROND - 40 - h, GROND - 80, 50):
            for wx in range(x + 18, x + w - 30, 40):
                if rng.random() < 0.55:
                    pygame.draw.rect(s, (255, 215, 110), (wx, wy, 20, 26))
        x += w + rng.randint(0, 20)
    return s


def maak_straat():
    s = pygame.Surface((WERELD, H - GROND))
    s.fill((120, 115, 125))
    pygame.draw.rect(s, (160, 155, 165), (0, 0, WERELD, 14))
    for y in range(14, H - GROND, 26):
        off = 0 if (y // 26) % 2 else 30
        for x in range(-off, WERELD, 60):
            pygame.draw.rect(s, (100, 95, 108), (x, y, 60, 26), 2)
    return s


# ---------------------------------------------------------------- het spel

class Plek:
    def __init__(self, x, soort, img):
        self.x, self.soort, self.img = x, soort, img
        self.breedte = img.get_width()
        self.is_huis = soort == 0
        self.bezorgd = False      # huis: heeft er al een Piet een cadeautje door de schoorsteen gegooid?
        self.bezorger = None      # de Piet die nu aan het bezorgen is
        self.bezorg_t = 0.0
        self.bezorg_van = 0.0
        self.schoen_t = 0.0


class Piet:
    """Een Piet die in de optocht achter Sinterklaas aan huppelt."""

    def __init__(self, x, nummer):
        self.x = x
        self.pak = PIET_PAKKEN[nummer % len(PIET_PAKKEN)]
        self.huid = PIET_HUID[nummer % len(PIET_HUID)]
        self.fase = random.uniform(0, 6)
        self.richting = 1
        self.loopt = False
        self.sprong = 0.0
        self.hup_klok = random.uniform(1, 4)


class SintSpel(c.Scene):
    def __init__(self):
        super().__init__()
        self.lucht = maak_lucht()
        self.daken = maak_daken()
        self.straat = maak_straat()
        self.sint_img = maak_sint()
        self.sint_img_l = pygame.transform.flip(self.sint_img, True, False)
        # om de paar plekken een huis (met schoorsteen-Piet), daartussen andere verstopplekken
        anderen = list(range(1, len(OBJECTEN)))
        random.shuffle(anderen)
        imgs = [obj_huis(licht=False)] + [m() for m in OBJECTEN[1:]]
        self.huis_licht = obj_huis(licht=True)
        self.huis_donker = imgs[0]
        self.s_blij = c.blij_deuntje()
        soorten = [0 if i % 3 == 1 else anderen[i % len(anderen)] for i in range(8)]
        self.plekken = [Plek(500 + i * 500, s, imgs[s]) for i, s in enumerate(soorten)]
        self.optocht = []
        self.kwijt = []            # verstopte Pieten die je kunt zoeken
        self.kwijt_klok = 0.0
        self.pieten_nummer = 0
        self.bezorgd = 0
        self.feest_t = None        # alle huizen bezorgd: feest, daarna een nieuwe nacht
        self.touw = None
        self.touw_klok = 8.0
        self.s_hoi = hoi()
        self.s_boing = boing()
        self.spring_t = None
        self.sint_x = 250.0
        self.richting = 1
        self.loop_fase = 0.0
        self.loop_tijd = 0.0
        self.cam = 0.0
        self.tijd = 0.0
        self.pepernoten = [x for x in range(420, WERELD - 100, 140) if random.random() < 0.7]
        self.vallend = []
        self.aantal_noten = 0
        self.gevonden = 0
        self.deeltjes = c.Deeltjes()
        self.popups = c.Popups()
        self.sneeuw = [[random.uniform(0, W), random.uniform(0, H), random.uniform(30, 70), random.uniform(2, 4)]
                       for _ in range(70)]
        self.actief_l = self.actief_r = 0.0
        self.s_hinnik = hinniken()
        self.s_hoef = [hoefje(True), hoefje(False)]
        self.s_pling = c.pling()
        self.s_fanfare = fanfare()
        # het paard begint verstopt een stukje verderop
        self.paard_plek = self.plekken[1]
        self.paard_toestand = "verstopt"
        self.paard_t = 0.0
        self.paard_x = self.verstop_x(self.paard_plek)
        self.paard_richting = self.verstop_richting(self.paard_plek)
        self.hoef_klok = 0.0
        self.gluur_klok = 2.0
        # de eerste Piet zit vlakbij verstopt, zodat ze meteen snapt hoe het werkt
        self.verstop_piet(self.plekken[0])

    # ---------------------------------------------------------------- paard

    def verstop_kant(self, plek):
        return -1 if plek.x > self.sint_x else 1   # staartje steekt uit aan de kant van Sint

    def verstop_x(self, plek):
        kant = self.verstop_kant(plek)
        return plek.x + kant * (plek.breedte / 2 - 75)

    def verstop_richting(self, plek):
        return -self.verstop_kant(plek)

    def nieuwe_verstopplek(self):
        bezet = {id(k["plek"]) for k in self.kwijt}
        kanten = [p for p in self.plekken if 600 < abs(p.x - self.sint_x) < 1800 and id(p) not in bezet]
        if not kanten:
            kanten = [p for p in self.plekken if p is not self.paard_plek]
        # liefst de andere kant op dan waar het paard nu staat, zodat beide pijltjes aan de beurt komen
        andere = [p for p in kanten if (p.x - self.sint_x) * (self.paard_x - self.sint_x) < 0]
        return random.choice(andere or kanten)

    def update_paard(self, dt):
        self.paard_t += dt
        t = self.paard_toestand
        if t == "verstopt":
            self.gluur_klok -= dt
            if self.gluur_klok < -1.2:
                self.gluur_klok = random.uniform(2.5, 4.0)
            if abs(self.sint_x - self.paard_plek.x) < self.paard_plek.breedte / 2 + 40:
                # het paard springt tevoorschijn, tussen Sint en de verstopplek, en kijkt naar Sint
                self.paard_toestand, self.paard_t = "gevonden", 0.0
                kant = 1 if self.paard_plek.x > self.sint_x else -1
                self.paard_x = self.sint_x + kant * 300
                self.paard_richting = -kant
                self.gevonden += 1
                self.s_hinnik.play()
                self.s_fanfare.play()
                sx = self.paard_x - self.cam
                self.deeltjes.burst(sx, GROND - 200, 70, snelheid=600)
                self.deeltjes.burst(sx, GROND - 200, 30, [(255, 230, 90), c.WIT], 500, "ster")
                self.popups.voeg("Gevonden!", W // 2, 200, (255, 220, 80), 100, 2.4)
                for _ in range(10):
                    self.vallend.append([self.paard_x + random.uniform(-450, 450), random.uniform(-300, -20), 0.0])
        elif t == "gevonden":
            if self.paard_t > 2.6:
                self.paard_plek = self.nieuwe_verstopplek()
                self.paard_doel = self.verstop_x(self.paard_plek)
                self.paard_richting = 1 if self.paard_doel > self.paard_x else -1
                self.paard_toestand, self.paard_t = "rennen", 0.0
                self.s_hinnik.play()
        elif t == "rennen":
            stap = 950 * dt * self.paard_richting
            self.hoef_klok += dt
            if self.hoef_klok > 0.14 and abs(self.paard_x - self.cam - W / 2) < W:
                self.hoef_klok = 0
                random.choice(self.s_hoef).play()
            if abs(self.paard_doel - self.paard_x) <= abs(stap):
                self.paard_x = self.paard_doel
                self.paard_richting = self.verstop_richting(self.paard_plek)
                self.paard_toestand, self.paard_t = "verstopt", 0.0
                self.gluur_klok = 1.5
            else:
                self.paard_x += stap

    # ---------------------------------------------------------------- pieten

    TOUW_DUUR = 4.5

    def update_pieten(self, dt):
        # optocht: elke Piet loopt naar zijn plekje achter Sint
        for i, p in enumerate(self.optocht):
            doel = self.sint_x - self.richting * (130 + i * 85)
            verschil = doel - p.x
            p.loopt = abs(verschil) > 6
            if p.loopt:
                p.x += verschil * min(1.0, dt * 3.5)
                p.richting = 1 if verschil > 0 else -1
                p.fase += dt * 12
            else:
                p.richting = self.richting
                p.hup_klok -= dt
                if p.hup_klok < 0:
                    p.hup_klok = random.uniform(2, 5)
                    p.sprong = 1.0
            p.sprong = max(0.0, p.sprong - dt * 1.8)

        # Piet aan een touw: zakt uit de lucht en strooit pepernoten
        if self.touw is None:
            self.touw_klok -= dt
            if self.touw_klok < 0 and self.paard_toestand != "gevonden":
                kant = random.choice((-1, 1))
                x = c.klem(self.sint_x + kant * random.uniform(200, 380), 150, WERELD - 150)
                self.touw = {"x": x, "t": 0.0, "pak": random.choice(PIET_PAKKEN),
                             "huid": random.choice(PIET_HUID), "gestrooid": False}
                self.touw_klok = random.uniform(10, 16)
        else:
            self.touw["t"] += dt
            t = self.touw["t"]
            if t > 1.3 and not self.touw["gestrooid"]:
                self.touw["gestrooid"] = True
                self.s_hoi.play()
                y = self.touw_y()
                for _ in range(12):
                    self.vallend.append([self.touw["x"] + random.uniform(-350, 350), y - 120, random.uniform(-500, -150)])
                self.popups.voeg("Strooien!", self.touw["x"] - self.cam, y - 230, (255, 220, 80), 56, 1.6)
            if t > self.TOUW_DUUR:
                self.touw = None

        self.update_kwijt(dt)
        self.update_bezorgen(dt)

    # ---- verstopte Pieten zoeken

    def verstop_piet(self, plek):
        kant = -1 if plek.x > self.sint_x else 1      # gluurt om de hoek aan de kant van Sint
        self.pieten_nummer += 1
        self.kwijt.append({"plek": plek, "kant": kant, "t": random.uniform(0, 3),
                           "pak": PIET_PAKKEN[self.pieten_nummer % len(PIET_PAKKEN)],
                           "huid": PIET_HUID[self.pieten_nummer % len(PIET_HUID)]})

    def aantal_pieten(self):
        bezig = sum(1 for p in self.plekken if p.bezorger is not None)
        return len(self.optocht) + len(self.kwijt) + bezig

    def update_kwijt(self, dt):
        for k in list(self.kwijt):
            k["t"] += dt
            plek = k["plek"]
            if abs(self.sint_x - plek.x) < plek.breedte / 2 + 40 and len(self.optocht) < MAX_OPTOCHT:
                self.kwijt.remove(k)
                x = plek.x + k["kant"] * (plek.breedte / 2 + 20)
                piet = Piet(x, 0)
                piet.pak, piet.huid, piet.sprong = k["pak"], k["huid"], 1.0
                self.optocht.append(piet)
                self.s_hoi.play()
                self.s_pling.play()
                sx = x - self.cam
                self.deeltjes.burst(sx, GROND - 120, 40, snelheid=450)
                self.popups.voeg("Piet gevonden!", sx, GROND - 280, (255, 220, 80), 60, 2.0)
                self.kwijt_klok = 3.0
        # nieuwe Piet verstoppen (één tegelijk, en niet te veel Pieten in totaal)
        self.kwijt_klok -= dt
        if self.kwijt_klok < 0 and len(self.kwijt) < 1 and self.aantal_pieten() < MAX_OPTOCHT:
            bezet = {id(k["plek"]) for k in self.kwijt} | {id(self.paard_plek)}
            vrij = [p for p in self.plekken if id(p) not in bezet and 450 < abs(p.x - self.sint_x) < 2000]
            if vrij:
                self.verstop_piet(random.choice(vrij))
            self.kwijt_klok = 4.0

    def teken_kwijt(self, s):
        for k in self.kwijt:
            plek = k["plek"]
            gluur = max(0.0, math.sin(k["t"] * 1.6)) * 30
            x = plek.x + k["kant"] * (plek.breedte / 2 - 15 + gluur) - self.cam
            if -150 < x < W + 150:
                teken_piet(s, x, GROND, k["pak"], k["huid"], k["kant"], k["t"] * 6, armen_omhoog=gluur > 20)

    # ---- cadeautjes bezorgen door de schoorsteen

    def schoorsteen(self, p):
        """Midden en bovenkant van de schoorsteen van een huis (wereldcoördinaten)."""
        return p.x + 71, GROND + 4 - 345 + 20

    def update_bezorgen(self, dt):
        for p in self.plekken:
            if not p.is_huis:
                continue
            if p.bezorgd:
                p.schoen_t += dt
            if p.bezorger is None:
                if not p.bezorgd and self.optocht and abs(self.sint_x - p.x) < 280 and self.feest_t is None:
                    piet = min(self.optocht, key=lambda q: abs(q.x - p.x))
                    self.optocht.remove(piet)
                    p.bezorger, p.bezorg_t, p.bezorg_van = piet, 0.0, piet.x
                    self.s_hoi.play()
                    self.popups.voeg("Hup!", piet.x - self.cam, GROND - 220, c.WIT, 56, 1.0)
                continue
            vorig = p.bezorg_t
            p.bezorg_t += dt
            if vorig < 1.5 <= p.bezorg_t:
                p.bezorgd = True
                p.img = self.huis_licht
                p.schoen_t = 0.0
                self.bezorgd += 1
                self.s_pling.play()
                self.s_blij.play()
                sx = p.x - self.cam
                self.deeltjes.burst(sx, GROND - 140, 50, [(255, 230, 90), c.WIT, (255, 150, 170)], 450, "ster")
                self.popups.voeg("Cadeautje!", sx, GROND - 440, (255, 220, 80), 64, 1.8)
            if p.bezorg_t > 2.7:
                piet = p.bezorger
                piet.x = p.x + (1 if self.sint_x > p.x else -1) * 170
                piet.sprong = 1.0
                self.optocht.append(piet)
                p.bezorger = None

        # alle huizen bezorgd: groot feest en daarna een nieuwe nacht
        huizen = [p for p in self.plekken if p.is_huis]
        if self.feest_t is None:
            if all(p.bezorgd and p.bezorger is None for p in huizen):
                self.feest_t = 0.0
                self.s_fanfare.play()
                self.popups.voeg("Alle cadeautjes bezorgd!", W // 2, 220, (255, 220, 80), 72, 3.5)
        else:
            self.feest_t += dt
            if random.random() < dt * 6:
                self.deeltjes.burst(random.uniform(100, W - 100), random.uniform(60, 300), 30, snelheid=500)
            if self.feest_t > 6.0:
                self.feest_t = None
                for p in huizen:
                    p.bezorgd = False
                    p.img = self.huis_donker
                self.popups.voeg("Nieuwe nacht!", W // 2, 220, c.WIT, 64, 2.0)

    def sprong_hoogte(self):
        if self.spring_t is None:
            return 0.0
        return math.sin(math.pi * c.klem(self.spring_t / SPRONG_DUUR)) * SPRONG_HOOGTE

    def touw_y(self):
        """Hoogte van de voeten van de touw-Piet."""
        t = self.touw["t"]
        laag = GROND - 230
        if t < 1.0:
            return c.lerp(-60, laag, c.ease_out(t))
        if t > self.TOUW_DUUR - 1.0:
            return c.lerp(laag, -60, c.ease_in(t - (self.TOUW_DUUR - 1.0)))
        return laag + math.sin(t * 3) * 8

    def teken_touw_piet(self, s):
        if self.touw is None:
            return
        x = self.touw["x"] - self.cam
        y = self.touw_y()
        pygame.draw.line(s, (210, 180, 120), (x, 0), (x, y - 160), 5)
        teken_piet(s, x, y, self.touw["pak"], self.touw["huid"], 1, self.tijd * 8, armen_omhoog=True)

    @staticmethod
    def teken_cadeautje(s, x, y, maat=14):
        pygame.draw.rect(s, (60, 130, 230), (x - maat, y - maat, 2 * maat, 2 * maat))
        pygame.draw.rect(s, (255, 215, 60), (x - maat * 0.22, y - maat, maat * 0.44, 2 * maat))
        pygame.draw.rect(s, (255, 215, 60), (x - maat, y - maat * 0.22, 2 * maat, maat * 0.44))

    def teken_huis_extra(self, s, p):
        """Wolkje met cadeautje boven een donker huis, of een schoen met cadeau voor de deur."""
        x = p.x - self.cam
        if not p.bezorgd and p.bezorger is None:
            y = GROND - 430 + math.sin(self.tijd * 3 + p.x) * 8
            for dx, dy, r in ((-26, 6, 22), (0, -6, 30), (26, 6, 22)):
                pygame.draw.circle(s, c.WIT, (x + dx, y + dy), r)
            pygame.draw.circle(s, c.WIT, (x - 30, y + 40), 7)
            pygame.draw.circle(s, c.WIT, (x - 40, y + 56), 4)
            self.teken_cadeautje(s, x, y, 14)
        elif p.bezorgd:
            k = c.ease_out_back(p.schoen_t / 0.5)
            if k > 0.05:
                sx, sy = x + 60, GROND - 4
                pygame.draw.ellipse(s, (150, 60, 40), (sx - 26 * k, sy - 22 * k, 52 * k, 24 * k))
                pygame.draw.rect(s, (150, 60, 40), (sx - 24 * k, sy - 38 * k, 18 * k, 26 * k), border_radius=4)
                self.teken_cadeautje(s, sx + 6 * k, sy - 30 * k, 11 * k)

    def teken_bezorger(self, s, p):
        piet = p.bezorger
        if piet is None:
            return
        t = p.bezorg_t
        sx, top = self.schoorsteen(p)
        sx -= self.cam
        in_schoorsteen = top + 45
        if t < 0.7:          # springt naar de schoorsteen
            k = c.ease_in_out(t / 0.7)
            x = c.lerp(p.bezorg_van - self.cam, sx, k)
            y = c.lerp(GROND, in_schoorsteen, k) - math.sin(math.pi * k) * 160
            teken_piet(s, x, y, piet.pak, piet.huid, 1 if sx > x else -1, t * 10, armen_omhoog=True,
                       S=c.lerp(0.9, 0.6, k))
            self.teken_cadeautje(s, x, y - c.lerp(0.9, 0.6, k) * 170 - 12, 14)
        elif t < 2.1:        # staat in de schoorsteen en gooit het cadeautje erin
            s.set_clip(pygame.Rect(0, 0, W, int(top)))
            teken_piet(s, sx, in_schoorsteen, piet.pak, piet.huid, -1, self.tijd * 8, armen_omhoog=True, S=0.6)
            s.set_clip(None)
            cy = in_schoorsteen - 170 * 0.6 - 12
            if t > 1.3:
                cy += (t - 1.3) ** 2 * 1500
            if cy < top - 8:
                self.teken_cadeautje(s, sx, cy, 14)
        else:                # springt terug naar de straat
            k = c.ease_in_out((t - 2.1) / 0.6)
            doel = p.x + (1 if self.sint_x > p.x else -1) * 170 - self.cam
            x = c.lerp(sx, doel, k)
            y = c.lerp(in_schoorsteen, GROND, k) - math.sin(math.pi * k) * 160
            teken_piet(s, x, y, piet.pak, piet.huid, 1 if doel > sx else -1, t * 10, armen_omhoog=True,
                       S=c.lerp(0.6, 0.9, k))
        pygame.draw.rect(s, (150, 30, 30), (sx - 25, top - 6, 50, 10))

    # ---------------------------------------------------------------- invoer

    def handle(self, e):
        k = c.toets(e)
        if e.type == pygame.KEYDOWN and e.key == pygame.K_SPACE and self.spring_t is None:
            self.spring_t = 0.0
            self.s_boing.play()
            for i, p in enumerate(self.optocht):
                p.sprong = 1.0 + i * 0.15
        if k == "links":
            self.richting = -1
            self.loop_tijd = 0.35
            self.actief_l = 1.0
        elif k == "rechts":
            self.richting = 1
            self.loop_tijd = 0.35
            self.actief_r = 1.0

    def update(self, dt):
        self.tijd += dt
        links, rechts = c.vast_links(), c.vast_rechts()
        if links and not rechts:
            self.richting, self.loop_tijd = -1, max(self.loop_tijd, 0.05)
        elif rechts and not links:
            self.richting, self.loop_tijd = 1, max(self.loop_tijd, 0.05)
        loopt = self.loop_tijd > 0
        if loopt:
            self.loop_tijd -= dt
            self.sint_x = c.klem(self.sint_x + self.richting * SNELHEID * dt, 120, WERELD - 120)
            self.loop_fase += dt * 10
        doel_cam = c.klem(self.sint_x - W / 2, 0, WERELD - W)
        self.cam += (doel_cam - self.cam) * min(1.0, dt * 6)

        rapers = [self.sint_x] + [p.x for p in self.optocht]
        for x in [x for x in self.pepernoten if any(abs(x - r) < 50 for r in rapers)]:
            self.pepernoten.remove(x)
            self.aantal_noten += 1
            self.s_pling.play()
            self.deeltjes.burst(x - self.cam, GROND - 20, 10, [(255, 230, 90)], 250, "ster", grootte=(5, 9))
        for v in self.vallend:
            v[2] += 900 * dt
            v[1] += v[2] * dt
        for v in [v for v in self.vallend if v[1] >= GROND - 14]:
            self.vallend.remove(v)
            self.pepernoten.append(c.klem(v[0], 150, WERELD - 150))

        if self.spring_t is not None:
            self.spring_t += dt
            if self.spring_t > SPRONG_DUUR:
                self.spring_t = None
        # in de lucht vangt Sint vallende pepernoten
        h = self.sprong_hoogte()
        for v in [v for v in self.vallend if abs(v[0] - self.sint_x) < 70 and GROND - 360 - h < v[1] < GROND - h]:
            self.vallend.remove(v)
            self.aantal_noten += 1
            self.s_pling.play()
            self.deeltjes.burst(v[0] - self.cam, v[1], 10, [(255, 230, 90)], 250, "ster", grootte=(5, 9))

        self.update_paard(dt)
        self.update_pieten(dt)
        for f in self.sneeuw:
            f[1] += f[2] * dt
            f[0] += math.sin(self.tijd + f[1] * 0.01) * 15 * dt
            if f[1] > H:
                f[1], f[0] = -5, random.uniform(0, W)
        self.actief_l = max(0.0, self.actief_l - dt * 4)
        self.actief_r = max(0.0, self.actief_r - dt * 4)
        self.deeltjes.update(dt)
        self.popups.update(dt)

    # ---------------------------------------------------------------- tekenen

    def teken_paard_nu(self, s):
        t = self.paard_toestand
        x = self.paard_x - self.cam
        if x < -300 or x > W + 300:
            return
        y = GROND
        if t == "verstopt" and self.gluur_klok < 0:
            y -= 75 * math.sin(math.pi * c.klem(-self.gluur_klok / 1.2))
        elif t == "gevonden":
            y -= abs(math.sin(self.paard_t * 7)) * 40
        teken_paard(s, x, y, self.paard_richting, self.tijd * 14, t == "rennen", self.tijd)

    def draw(self, s):
        s.blit(self.lucht, (0, 0))
        s.blit(self.daken, (-self.cam * 0.4, 0))
        s.blit(self.straat, (-self.cam, GROND))

        if self.paard_toestand == "verstopt":
            self.teken_paard_nu(s)
        self.teken_kwijt(s)
        for p in self.plekken:
            x = p.x - self.cam
            if -400 < x < W + 400:
                s.blit(p.img, p.img.get_rect(midbottom=(x, GROND + 4)))
                if p.is_huis:
                    self.teken_huis_extra(s, p)
        for p in self.plekken:
            if p.is_huis and -400 < p.x - self.cam < W + 400:
                self.teken_bezorger(s, p)
        self.teken_touw_piet(s)
        for x in self.pepernoten:
            sx = x - self.cam
            if -20 < sx < W + 20:
                pygame.draw.circle(s, PEPERNOOT, (sx, GROND - 12), 12)
                pygame.draw.circle(s, (205, 140, 80), (sx - 3, GROND - 15), 4)
        for vx, vy, _ in self.vallend:
            pygame.draw.circle(s, PEPERNOOT, (vx - self.cam, vy), 12)
        if self.paard_toestand != "verstopt":
            self.teken_paard_nu(s)

        # de optocht van Pieten achter Sint
        for p in self.optocht:
            px = p.x - self.cam
            if -100 < px < W + 100:
                hup = abs(math.sin(p.fase)) * 10 if p.loopt else 0
                hup += math.sin(math.pi * min(1.0, p.sprong)) * 70
                teken_piet(s, px, GROND - hup, p.pak, p.huid, p.richting, p.fase, p.loopt,
                           armen_omhoog=p.sprong > 0, S=0.9)

        # Sinterklaas
        sx = self.sint_x - self.cam
        loopt = self.loop_tijd > 0
        bob = abs(math.sin(self.loop_fase)) * 6 if loopt else 0
        bob += self.sprong_hoogte()
        for i, kant in enumerate((-1, 1)):
            voet = math.sin(self.loop_fase + i * math.pi) * 14 if loopt else 0
            pygame.draw.ellipse(s, c.ZWART, (sx + kant * 30 + voet - 18, GROND - 14 - bob, 40, 16))
        img = self.sint_img if self.richting > 0 else self.sint_img_l
        kantel = math.sin(self.loop_fase) * 3 if loopt else 0
        img = pygame.transform.rotate(img, kantel) if kantel else img
        s.blit(img, img.get_rect(midbottom=(sx, GROND - 8 - bob)))

        for x, y, _, r in self.sneeuw:
            pygame.draw.circle(s, c.WIT, (x, y), r)
        self.deeltjes.draw(s)
        self.popups.draw(s)
        self.teken_hud(s)

    def hint_richting(self):
        """-1 of 1: de kant van het dichtstbijzijnde doel (paard, verstopte Piet of donker huis). 0 = geen."""
        doelen = [k["plek"].x for k in self.kwijt]
        if self.paard_toestand == "verstopt":
            doelen.append(self.paard_plek.x)
        if self.optocht:   # met een Piet erbij kun je ook cadeautjes gaan bezorgen
            doelen += [p.x for p in self.plekken if p.is_huis and not p.bezorgd and p.bezorger is None]
        doelen = [x - self.sint_x for x in doelen if abs(x - self.sint_x) > 150]
        if not doelen:
            return 0
        return 1 if min(doelen, key=abs) > 0 else -1

    def teken_hud(self, s):
        # pepernoten-teller
        pygame.draw.circle(s, PEPERNOOT, (50, 50), 26)
        pygame.draw.circle(s, (205, 140, 80), (42, 42), 8)
        c.tekst(s, str(self.aantal_noten), 52, c.WIT, (110, 50))
        self.teken_cadeautje(s, 200, 50, 22)
        c.tekst(s, str(self.bezorgd), 52, c.WIT, (260, 50))
        # een gouden ster voor elke keer dat het paard gevonden is
        for i in range(min(self.gevonden, 12)):
            x = W - 50 - i * 52
            pygame.draw.polygon(s, GOUD, c.sterpunten(x, 50, 24, 11))
            pygame.draw.polygon(s, c.ZWART, c.sterpunten(x, 50, 24, 11), 2)
        # pijltjes: de kant van het paard knippert
        bob = math.sin(self.tijd * 5) * 6
        richting_paard = self.hint_richting()
        knipper = 0.5 + 0.5 * math.sin(self.tijd * 8)
        for richting, actief, x in ((-1, self.actief_l, 80), (1, self.actief_r, W - 80)):
            if richting == richting_paard:
                c.pijl(s, (x, H // 2 + bob), richting, 60, (255, 220, 60), actief=max(actief, knipper * 0.8))
            else:
                c.pijl(s, (x, H // 2 + bob), richting, 38, (200, 200, 210), actief=actief)


if __name__ == "__main__":
    c.los_starten(SintSpel)
