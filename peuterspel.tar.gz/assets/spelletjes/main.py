"""Het menu met alle spelletjes.

  links / rechts = ander spelletje kiezen
  Enter of spatie = beginnen (het groene bolletje staat onder het gekozen spelletje).
  Esc = terug naar dit menu, Ctrl+Q = stoppen.
"""
import asyncio
import math
import random

import pygame

from . import common as c
from .common import W, H
from . import dansen, kado, sint, stickers, tosti

NAAM = ""          # zet hier de naam van je dochter, bijvoorbeeld "Emma"


class Menu(c.Scene):
    def __init__(self, keuze=0):
        super().__init__()
        self.spellen = [
            ("Tosti", (255, 166, 77), tosti.TostiSpel),
            ("Dansen", (167, 112, 255), dansen.DansSpel),
            ("Stickers", (64, 196, 180), stickers.StickerSpel),
            ("Sinterklaas", (230, 70, 80), sint.SintSpel),
            ("Kado's", (70, 110, 200), kado.KadoSpel),
        ]
        self.keuze = keuze
        self.tijd = 0.0
        self.wiebel = 0.0
        self.s_blip = c.blip(700)
        self.s_plop = c.plop(1.2)
        self.tosti_img = tosti.maak_tosti(180, gezicht=True)
        st = stickers.alle_stickers()
        self.sticker_imgs = [pygame.transform.rotozoom(st[i], h, 0.62) for i, h in ((1, -15), (0, 12), (11, -5))]
        self.sint_img = pygame.transform.rotozoom(sint.maak_sint(), 0, 0.55)
        self.bellen = [[random.uniform(0, W), random.uniform(0, H), random.uniform(10, 30), random.choice(c.FEEST)]
                       for _ in range(25)]
        n = len(self.spellen)
        breedte, gat = 212, 22
        links = (W - n * breedte - (n - 1) * gat) / 2
        self.kaarten = [pygame.Rect(int(links + i * (breedte + gat)), 190, breedte, 360) for i in range(n)]

    def start(self):
        self.s_plop.play()
        self.volgende = self.spellen[self.keuze][2]
        self.klaar = True

    aanraken = True     # het menu handelt tikken zelf af

    def tik(self, pos):
        """Tikken op een kaart kiest hem; nog een keer tikken (of op het groene bolletje) start."""
        for i, r in enumerate(self.kaarten):
            bolletje = pygame.Rect(r.centerx - 50, r.bottom + 10, 100, 110)
            if r.inflate(20, 20).collidepoint(pos) or (i == self.keuze and bolletje.collidepoint(pos)):
                if i == self.keuze:
                    self.start()
                else:
                    self.keuze = i
                    self.wiebel = 1.0
                    self.s_blip.play()
                return
        if pos[0] < 140 or pos[0] > W - 140:      # op een pijl tikken
            self.handle(c.toets_event(pygame.K_LEFT if pos[0] < 140 else pygame.K_RIGHT))

    def handle(self, e):
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            self.tik(e.pos)
            return
        k = c.toets(e)
        if k is None:
            return
        if e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.start()
            return
        if k in ("links", "rechts"):
            self.keuze = (self.keuze + (-1 if k == "links" else 1)) % len(self.spellen)
            self.wiebel = 1.0
            self.s_blip.play()

    def update(self, dt):
        self.tijd += dt
        self.wiebel = max(0.0, self.wiebel - dt * 3)
        for b in self.bellen:
            b[1] -= b[2] * dt * 2
            if b[1] < -40:
                b[0], b[1] = random.uniform(0, W), H + 40

    def teken_icoon(self, s, i, mid):
        x, y = mid
        bob = math.sin(self.tijd * 3 + i) * 6
        if i == 0:
            s.blit(self.tosti_img, self.tosti_img.get_rect(center=(x, y + bob)))
        elif i == 1:
            p = dansen.pose(int(self.tijd / 4) % len(dansen.DANSEN), self.tijd * 2)
            dansen.teken_danser(s, x, y + 95, p, "meisje", (255, 112, 166), 0.75)
        elif i == 2:
            for j, img in enumerate(self.sticker_imgs):
                s.blit(img, img.get_rect(center=(x - 50 + j * 50, y - 30 + (j % 2) * 60 + bob)))
        elif i == 3:
            s.blit(self.sint_img, self.sint_img.get_rect(center=(x, y + bob)))
        else:
            kado.teken_schoen(s, x + 10, y + 70, 1.6)
            kado.teken_kado(s, x - 14, y + 10 + bob, 34, kado.KADO_KLEUREN[0])

    def draw(self, s):
        s.blit(c.verloop((120, 200, 255), (255, 220, 240)), (0, 0))
        for x, y, r, kleur in self.bellen:
            pygame.draw.circle(s, c.mengkleur(kleur, c.WIT, 0.5), (x, y), r)
        titel = f"Spelletjes van {NAAM}!" if NAAM else "Spelletjes!"
        c.regenboogtekst(s, titel, 90, (W // 2, 95), self.tijd)

        for i, (naam, kleur, _) in enumerate(self.spellen):
            r = self.kaarten[i]
            gekozen = i == self.keuze
            if gekozen:
                groei = 18 + math.sin(self.tijd * 5) * 5
                r = r.inflate(groei, groei)
                pygame.draw.rect(s, (255, 240, 120), r.inflate(26, 26), border_radius=44)
            pygame.draw.rect(s, (0, 0, 0), r.move(5, 8), border_radius=36)
            pygame.draw.rect(s, kleur, r, border_radius=36)
            pygame.draw.rect(s, c.WIT, r, 7, border_radius=36)
            self.teken_icoon(s, i, (r.centerx, r.centery - 30))
            c.tekst(s, naam, 42 if len(naam) < 10 else 32, c.WIT, (r.centerx, r.bottom - 45))
            if gekozen:
                # groen startknopje: druk op Enter om te beginnen
                m = 30 + math.sin(self.tijd * 5) * 3
                cx, cy = r.centerx, r.bottom + 62
                pygame.draw.circle(s, (0, 0, 0), (cx + 3, cy + 5), m)
                pygame.draw.circle(s, (80, 200, 90), (cx, cy), m)
                pygame.draw.circle(s, c.WIT, (cx, cy), m, 5)
                pygame.draw.polygon(s, c.WIT, [(cx - 9, cy - 14), (cx - 9, cy + 14), (cx + 15, cy)])

        bob = math.sin(self.tijd * 5) * 6
        c.pijl(s, (70, 370 + bob), -1, 44, actief=self.wiebel)
        c.pijl(s, (W - 70, 370 + bob), 1, 44, actief=self.wiebel)
        uitleg = ("Tik op een spelletje om te beginnen  -  huisje bovenin vasthouden = terug naar menu" if c.WEB else
                  "Enter of spatie = beginnen  -  Esc = terug naar menu  -  Ctrl+Q = stoppen")
        c.tekst(s, uitleg, 22, (90, 90, 120), (W // 2, H - 30), rand=None)


async def hoofdlus():
    scherm = c.start_scherm("Spelletjes")
    keuze = 0
    try:
        while True:
            menu = Menu(keuze)
            spel = await c.speel(scherm, menu, escape_mag=False)
            keuze = menu.keuze
            if spel:
                await c.speel(scherm, spel())
    except c.Stoppen:
        pass
    finally:
        pygame.quit()


def main():
    asyncio.run(hoofdlus())


if __name__ == "__main__":
    main()
