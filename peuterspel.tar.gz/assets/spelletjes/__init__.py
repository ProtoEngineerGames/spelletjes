"""Kleine spelletjes voor een peuter. Start met: python -m spelletjes"""
