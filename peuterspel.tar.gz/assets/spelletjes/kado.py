"""Kado's brengen: Piet loopt 's avonds langs de achterkant van de huizen.

Kijk door de ramen naar binnen. Staat er op de vensterbank een lege schoen,
dan moet daar nog een cadeautje in. Sinterklaas loopt over de daken mee en
wijst aan waar nog een cadeautje moet komen.

  links / rechts = Piet loopt
  spatie         = springen (bij een huis met een lege schoen)
  spatie         = nog een keer: cadeautje brengen. Piet gaat om de beurt
                   door de schuifpui, door de schoorsteen of door het raam naar binnen.
  (pijltje omhoog en Enter werken ook als spatie)

Er zijn verschillende huizen: puntdak, plat dak of trapgevel, met één of twee
verdiepingen, soms gespiegeld, met allerlei muren, kozijnen en bovenramen.
"""
import math
import random

import pygame

from . import common as c
from .common import W, H
from .sint import PIET_HUID, PIET_PAKKEN, boing, fanfare, hoi, maak_lucht, maak_sint, teken_piet

GROND = 640
HUIS_B = 420
BENEDEN = 380                  # hoogte van een huis met één verdieping (inclusief dak)
BOVEN = 140                    # een extra verdieping
AFSTAND = 600
AANTAL = 9
EERSTE = 700
WERELD = EERSTE + (AANTAL - 1) * AFSTAND + 500
SNELHEID = 340
S = 0.8                        # grootte van Piet
SPRONG = 0.55                  # duur van een sprong
ACTIE = (pygame.K_SPACE, pygame.K_UP, pygame.K_RETURN, pygame.K_KP_ENTER)
MUUR_TOP = 140                 # bovenkant van de muur in elk huis (daarboven het dak)

MANIEREN = ("schuifpui", "schoorsteen", "raam")    # om de beurt
DUUR = {"schoorsteen": 2.5, "raam": 2.5, "schuifpui": 3.5}
KADO_MOMENT = {"schoorsteen": 1.7, "raam": 1.35, "schuifpui": 1.9}

BAKSTEEN = [(170, 85, 60), (150, 95, 75), (185, 110, 70), (140, 70, 60), (175, 130, 95)]
PLEISTER = [(240, 230, 210), (250, 215, 200), (210, 230, 240), (230, 240, 205)]
HOUT = [(90, 120, 150), (150, 70, 60), (70, 110, 85), (60, 60, 70)]
DAK = [(60, 55, 75), (110, 50, 45), (50, 70, 80), (80, 60, 50)]
KOZIJN = [(255, 255, 255), (40, 110, 70), (40, 70, 140), (40, 40, 45), (150, 40, 40)]
ALU = (65, 70, 85)
BEHANG = [((255, 236, 200), (250, 215, 170)), ((215, 235, 255), (190, 215, 245)),
          ((235, 255, 215), (210, 240, 190)), ((255, 220, 235), (245, 195, 215))]
KADO_KLEUREN = [((230, 60, 70), (255, 215, 60)), ((60, 130, 230), (255, 215, 60)),
                ((80, 190, 100), (255, 140, 190)), ((170, 80, 210), c.WIT), ((250, 150, 40), (60, 130, 230))]
SOORTEN = [(d, v) for d in ("punt", "plat", "trap") for v in (1, 2)]
TRAPPEN = [(15, 75, -10), (75, 135, -45), (135, 190, -80), (190, 230, -115), (230, 285, -80),
           (285, 345, -45), (345, 405, -10)]


# ---------------------------------------------------------------- geluidjes

def schuif():
    buf = c.leeg(0.5)
    c.ruis(buf, 0, 0.45, 0.25, 1.0, 0.9)
    c.glijtoon(buf, 0, 0.45, 180, 260, 0.15, 1.0)
    return c.geluid(buf, 0.6)


def piep():
    """Krakend raampje."""
    buf = c.leeg(0.45)
    c.glijtoon(buf, 0, 0.4, 700, 1100, 0.2, 1.5, trilling=0.08)
    return c.geluid(buf, 0.4)


def glij_omlaag():
    buf = c.leeg(0.6)
    c.glijtoon(buf, 0, 0.55, 900, 200, 0.35, 1.2)
    c.ruis(buf, 0.1, 0.4, 0.15, 2, 0.7)
    return c.geluid(buf, 0.5)


def glij_omhoog():
    buf = c.leeg(0.45)
    c.glijtoon(buf, 0, 0.4, 250, 1000, 0.35, 1.2)
    return c.geluid(buf, 0.5)


# ---------------------------------------------------------------- tekenen

def teken_kado(s, x, y, maat, kleuren, strik=True):
    """Cadeautje, midden-onder op (x, y)."""
    doos, lint = kleuren
    r = pygame.Rect(0, 0, maat * 2, maat * 1.7)
    r.midbottom = (x, y)
    pygame.draw.rect(s, doos, r, border_radius=max(1, int(maat * 0.2)))
    pygame.draw.rect(s, lint, (x - maat * 0.2, r.top, maat * 0.4, r.height))
    pygame.draw.rect(s, lint, (r.left, r.centery - maat * 0.2, r.width, maat * 0.4))
    if strik:
        for k in (-1, 1):
            pygame.draw.ellipse(s, lint, (x + k * maat * 0.45 - maat * 0.4, r.top - maat * 0.5, maat * 0.8, maat * 0.55))


def teken_schoen(s, x, y, maat=1.0):
    """Schoen, midden-onder op (x, y)."""
    bruin, donker = (165, 75, 45), (120, 50, 30)
    pygame.draw.ellipse(s, bruin, (x - 34 * maat, y - 26 * maat, 68 * maat, 26 * maat))
    pygame.draw.rect(s, bruin, (x - 30 * maat, y - 44 * maat, 26 * maat, 32 * maat), border_radius=int(6 * maat))
    pygame.draw.ellipse(s, donker, (x - 28 * maat, y - 48 * maat, 22 * maat, 9 * maat))


def teken_glas(s, x, y, w, h, kozijn, breedte=None, roede=False):
    """Een ruit met kozijn. breedte < w: het raam staat open (draait naar buiten)."""
    breedte = w if breedte is None else breedte
    if breedte < 4:
        return
    glas = pygame.Surface((max(1, int(breedte)), h), pygame.SRCALPHA)
    glas.fill((175, 215, 250, 90))
    pygame.draw.line(glas, (255, 255, 255, 140), (breedte * 0.15, h * 0.2), (breedte * 0.55, h * 0.05), 7)
    pygame.draw.line(glas, (255, 255, 255, 100), (breedte * 0.1, h * 0.5), (breedte * 0.75, h * 0.18), 4)
    s.blit(glas, (x, y))
    pygame.draw.rect(s, kozijn, (x, y, breedte, h), 7)
    if roede:
        pygame.draw.line(s, kozijn, (x, y + h * 0.35), (x + breedte, y + h * 0.35), 4)


def huis_x(nr):
    return EERSTE + nr * AFSTAND


# ---------------------------------------------------------------- een huis

class Huis:
    """Achterkant van een huis. De gevel heeft gaten voor het raam en de schuifpui,
    daarachter ligt de kamer (met de schoen op de vensterbank)."""

    def __init__(self, nr, soort, rng):
        self.nr = nr
        self.x = huis_x(nr)
        self.dak, self.verdiepingen = soort
        self.spiegel = rng.random() < 0.5
        self.h = BENEDEN + (BOVEN if self.verdiepingen == 2 else 0)
        self.vol = False          # staat er al een cadeautje in de schoen?
        self.pop_t = 9.0          # tijd sinds het cadeautje erin kwam (voor het oppoppen)
        self.kado = rng.choice(KADO_KLEUREN)
        self.raam_open = 0.0      # 0 = dicht, 1 = open
        self.pui_open = 0.0
        self.roet_t = None        # schoorsteen-roetwolkje
        self.kozijn = rng.choice(KOZIJN)
        self.zzz = []             # bovenramen met een slapend kindje

        B = self.h
        # plattegrond zonder spiegelen; hieronder wordt alles zo nodig omgeklapt
        raam = pygame.Rect(45, B - 200, 150, 140)
        pui = pygame.Rect(250, B - 215, 130, 180)
        schoorsteen = {"punt": pygame.Rect(296, MUUR_TOP - 112, 44, 100),
                       "plat": pygame.Rect(300, MUUR_TOP - 85, 44, 75),
                       "trap": pygame.Rect(295, MUUR_TOP - 125, 40, 85)}[self.dak]
        self.vloer = B - 35       # binnen ligt de vloer iets hoger dan de tuin (opstapje)
        self.bank_y = B - 80      # bovenkant van de vensterbank binnen

        self.gevel = self.maak_gevel(raam, pui, schoorsteen, rng)
        self.binnen = self.maak_binnen(raam, pui, rng)
        if self.spiegel:
            self.gevel = pygame.transform.flip(self.gevel, True, False)
            self.binnen = pygame.transform.flip(self.binnen, True, False)
            raam, pui, schoorsteen = (self.klap(r) for r in (raam, pui, schoorsteen))
            self.zzz = [(HUIS_B - x, y) for x, y in self.zzz]
        self.raam, self.pui, self.schoorsteen = raam, pui, schoorsteen
        self.schoen_x = raam.centerx
        # waar Piet staat te wachten voor de tweede spatie
        sx = schoorsteen.centerx + (-56 if schoorsteen.centerx > HUIS_B / 2 else 56)
        self.wacht = {"schoorsteen": (sx, self.dak_lokaal(sx)),
                      "raam": (raam.centerx, raam.bottom),
                      "schuifpui": (pui.left + 32 if not self.spiegel else pui.right - 32, self.vloer)}

    @staticmethod
    def klap(r):
        return pygame.Rect(HUIS_B - r.right, r.top, r.width, r.height)

    @property
    def links(self):
        return self.x - HUIS_B / 2

    @property
    def top(self):
        return GROND - self.h

    def wereld(self, lx, ly):
        return self.links + lx, self.top + ly

    def dak_lokaal(self, x):
        """Waar je op het dak staat (lokale y) op lokale x."""
        if self.spiegel:
            x = HUIS_B - x
        if self.dak == "punt":
            return MUUR_TOP - 98 + abs(x - HUIS_B / 2) / (HUIS_B / 2) * 110
        if self.dak == "plat":
            return MUUR_TOP - 14
        for x0, x1, dy in TRAPPEN:
            if x0 <= x < x1:
                return MUUR_TOP + dy - 6
        return MUUR_TOP

    def dak_wereld(self, wx):
        return self.top + self.dak_lokaal(c.klem(wx - self.links, 0, HUIS_B - 1))

    # ---- plaatjes maken

    def maak_gevel(self, raam, pui, schoorsteen, rng):
        B, T = self.h, MUUR_TOP
        s = pygame.Surface((HUIS_B, B), pygame.SRCALPHA)
        dakkleur = rng.choice(DAK)
        steen_rood = (175, 60, 50)
        if self.dak != "plat":                      # schoorsteen achter het dak
            pygame.draw.rect(s, steen_rood, schoorsteen)

        # muur: vorm (eventueel met trapgevel) gevuld met een patroon
        vorm = pygame.Surface((HUIS_B, B), pygame.SRCALPHA)
        pygame.draw.rect(vorm, (255, 255, 255), (15, T, HUIS_B - 30, B - T))
        if self.dak == "trap":
            for x0, x1, dy in TRAPPEN:
                pygame.draw.rect(vorm, (255, 255, 255), (x0, T + dy, x1 - x0, -dy + 1))
        muur = self.muurpatroon(rng, B)
        muur.blit(vorm, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        s.blit(muur, (0, 0))

        # dak
        if self.dak == "punt":
            pygame.draw.polygon(s, dakkleur, [(0, T + 12), (HUIS_B / 2, T - 98), (HUIS_B, T + 12)])
            pannen = c.mengkleur(dakkleur, c.ZWART, 0.25)
            for k in range(1, 6):
                t = k / 6
                pygame.draw.line(s, pannen, (c.lerp(HUIS_B / 2, 0, t), c.lerp(T - 98, T + 12, t)),
                                 (c.lerp(HUIS_B / 2, HUIS_B, t), c.lerp(T - 98, T + 12, t)), 3)
            pygame.draw.rect(s, c.WIT, (0, T + 8, HUIS_B, 10), border_radius=4)
            if rng.random() < 0.7:                  # dakkapel
                d = pygame.Rect(62, T - 62, 92, 64)
                pygame.draw.rect(s, c.mengkleur(dakkleur, c.WIT, 0.15), d)
                pygame.draw.rect(s, c.WIT, (d.left - 6, d.top - 10, d.width + 12, 12), border_radius=3)
                pygame.draw.rect(s, (255, 220, 130), d.inflate(-26, -22))
                pygame.draw.rect(s, self.kozijn, d.inflate(-26, -22), 5)
        elif self.dak == "plat":
            pygame.draw.rect(s, (120, 120, 130), (5, T - 14, HUIS_B - 10, 18), border_radius=3)
            pygame.draw.rect(s, steen_rood, schoorsteen)
            if rng.random() < 0.6:                  # antenne
                pygame.draw.line(s, (90, 90, 100), (90, T - 14), (90, T - 80), 4)
                for i in range(3):
                    pygame.draw.line(s, (90, 90, 100), (70 + i * 6, T - 70 + i * 16), (110 - i * 6, T - 70 + i * 16), 3)
        else:
            for x0, x1, dy in TRAPPEN:
                pygame.draw.rect(s, (235, 235, 235), (x0 - 4, T + dy - 6, x1 - x0 + 8, 8), border_radius=2)
            pygame.draw.circle(s, (255, 220, 130), (HUIS_B / 2, T - 70), 17)
            pygame.draw.circle(s, self.kozijn, (HUIS_B / 2, T - 70), 17, 4)
        pygame.draw.rect(s, (140, 45, 40), (schoorsteen.left - 5, schoorsteen.top, schoorsteen.width + 10, 12))

        # bovenverdieping: twee ramen met wat erachter
        if self.verdiepingen == 2:
            inhoud = ["slapen", rng.choice(("gordijn", "kat", "plant", "gordijn"))]
            rng.shuffle(inhoud)
            for wx, wat in zip((60, 250), inhoud):
                self.bovenraam(s, pygame.Rect(wx, T + 28, 110, 92), wat, rng)

        # gaten voor raam en schuifpui (daar kijk je naar binnen)
        pygame.draw.rect(s, self.kozijn, raam.inflate(18, 18), border_radius=4)
        pygame.draw.rect(s, ALU, pui.inflate(18, 18), border_radius=4)
        for r in (raam, pui):
            pygame.draw.rect(s, (0, 0, 0, 0), r)
        # buitenvensterbank (soms met bloempotjes) en opstapje voor de pui
        pygame.draw.rect(s, (225, 225, 230), (raam.left - 14, raam.bottom + 6, raam.width + 28, 12), border_radius=3)
        pygame.draw.rect(s, (150, 150, 160), (pui.left - 14, self.vloer + 8, pui.width + 28, B - self.vloer - 8))
        pygame.draw.rect(s, (185, 185, 195), (pui.left - 14, self.vloer + 8, pui.width + 28, 8))
        if rng.random() < 0.5:
            for px in (pui.right + 2,):
                pygame.draw.polygon(s, (190, 95, 60), [(px - 4, B - 40), (px + 26, B - 40), (px + 20, B), (px + 2, B)])
                for i in range(5):
                    pygame.draw.circle(s, (60, 150, 70), (px + 11 + math.cos(i) * 12, B - 50 - i * 6), 9)
                pygame.draw.circle(s, (255, 120, 160), (px + 11, B - 78), 7)
        # buitenlampje naast de pui
        pygame.draw.circle(s, (255, 230, 140), (pui.left - 22, pui.top + 50), 9)
        pygame.draw.rect(s, (60, 60, 70), (pui.left - 28, pui.top + 38, 12, 6))
        return s

    def muurpatroon(self, rng, B):
        s = pygame.Surface((HUIS_B, B), pygame.SRCALPHA)
        soort = rng.choice(("steen", "steen", "pleister", "hout"))
        if soort == "steen":
            kleur = rng.choice(BAKSTEEN)
            s.fill(kleur)
            donker = c.mengkleur(kleur, c.ZWART, 0.18)
            for i, y in enumerate(range(0, B, 20)):
                pygame.draw.line(s, donker, (0, y), (HUIS_B, y), 2)
                for x in range((i % 2) * 22, HUIS_B, 44):
                    pygame.draw.line(s, donker, (x, y), (x, y + 20), 2)
        elif soort == "pleister":
            kleur = rng.choice(PLEISTER)
            s.fill(kleur)
            pygame.draw.rect(s, c.mengkleur(kleur, c.ZWART, 0.3), (0, B - 30, HUIS_B, 30))
        else:
            kleur = rng.choice(HOUT)
            s.fill(kleur)
            for y in range(0, B, 18):
                pygame.draw.line(s, c.mengkleur(kleur, c.ZWART, 0.3), (0, y), (HUIS_B, y), 3)
                pygame.draw.line(s, c.mengkleur(kleur, c.WIT, 0.15), (0, y + 3), (HUIS_B, y + 3), 1)
        return s

    def bovenraam(self, s, r, wat, rng):
        if wat == "slapen":
            pygame.draw.rect(s, (70, 80, 140), r)
            pygame.draw.rect(s, (230, 230, 245), (r.left + 10, r.bottom - 34, 34, 18), border_radius=8)   # kussen
            pygame.draw.rect(s, rng.choice(((240, 120, 160), (120, 170, 240), (250, 200, 80))),
                             (r.left + 30, r.bottom - 30, r.width - 34, 30), border_radius=10)           # dekbed
            pygame.draw.circle(s, (255, 215, 185), (r.left + 30, r.bottom - 34), 14)
            c.gezichtje(s, r.left + 30, r.bottom - 34, 26, ogen_dicht=True)
            pygame.draw.circle(s, (250, 240, 180), (r.right - 20, r.top + 18), 8)                         # nachtlampje
            self.zzz.append((r.left + 55, r.top + 30))
        else:
            pygame.draw.rect(s, (255, 225, 150), r)
            if wat == "gordijn":
                kleur = rng.choice(((200, 60, 80), (70, 140, 90), (90, 90, 190)))
                pygame.draw.polygon(s, kleur, [(r.left, r.top), (r.left + 36, r.top), (r.left + 18, r.bottom),
                                               (r.left, r.bottom)])
                pygame.draw.polygon(s, kleur, [(r.right, r.top), (r.right - 36, r.top), (r.right - 18, r.bottom),
                                               (r.right, r.bottom)])
            elif wat == "kat":
                kleur = rng.choice(((60, 60, 70), (230, 140, 60), (240, 240, 240)))
                kx, ky = r.centerx, r.bottom - 4
                pygame.draw.ellipse(s, kleur, (kx - 28, ky - 30, 50, 30))
                pygame.draw.circle(s, kleur, (kx + 24, ky - 32), 14)
                for ox in (16, 30):
                    pygame.draw.polygon(s, kleur, [(kx + ox - 6, ky - 40), (kx + ox + 6, ky - 40), (kx + ox, ky - 54)])
                pygame.draw.line(s, kleur, (kx - 26, ky - 8), (kx - 44, ky - 30), 6)
                for ox in (19, 29):
                    pygame.draw.circle(s, (120, 200, 90), (kx + ox, ky - 34), 3)
            else:
                pygame.draw.polygon(s, (190, 95, 60), [(r.centerx - 16, r.bottom - 28), (r.centerx + 16, r.bottom - 28),
                                                       (r.centerx + 12, r.bottom), (r.centerx - 12, r.bottom)])
                for i in range(6):
                    a = -math.pi / 2 + (i - 2.5) * 0.45
                    pygame.draw.line(s, (60, 150, 70), (r.centerx, r.bottom - 28),
                                     (r.centerx + math.cos(a) * 34, r.bottom - 28 + math.sin(a) * 40), 7)
        pygame.draw.rect(s, self.kozijn, r.inflate(14, 14), 7, border_radius=3)
        pygame.draw.line(s, self.kozijn, (r.centerx, r.top), (r.centerx, r.bottom), 4)
        pygame.draw.rect(s, (225, 225, 230), (r.left - 10, r.bottom + 6, r.width + 20, 9), border_radius=3)

    def maak_binnen(self, raam, pui, rng):
        """De kamer achter het raam en de pui (zonder vensterbank)."""
        B = self.h
        s = pygame.Surface((HUIS_B, B), pygame.SRCALPHA)
        licht, streep = rng.choice(BEHANG)
        boven = B - 230
        pygame.draw.rect(s, licht, (20, boven, HUIS_B - 40, self.vloer - boven))
        for x in range(30, HUIS_B - 20, 34):
            pygame.draw.rect(s, streep, (x, boven, 12, self.vloer - boven))
        pygame.draw.rect(s, (175, 120, 80), (20, self.vloer, HUIS_B - 40, B - self.vloer))
        # lamp boven het raam
        lx = raam.centerx + 10
        pygame.draw.line(s, (80, 80, 80), (lx, boven), (lx, boven + 45), 3)
        pygame.draw.polygon(s, rng.choice(((250, 200, 80), (240, 120, 120), (120, 200, 200))),
                            [(lx - 22, boven + 60), (lx + 22, boven + 60), (lx + 10, boven + 42), (lx - 10, boven + 42)])
        # achter de pui: een open haard of een stoel
        hx = pui.right - 70
        if rng.random() < 0.6:
            pygame.draw.rect(s, (200, 200, 210), (hx - 10, self.vloer - 110, 90, 110))
            pygame.draw.rect(s, (230, 230, 240), (hx - 18, self.vloer - 118, 106, 12))
            pygame.draw.rect(s, (40, 30, 30), (hx + 8, self.vloer - 80, 54, 80), border_top_left_radius=20,
                             border_top_right_radius=20)
            for i, kleur in enumerate(((240, 90, 30), (255, 170, 40), (255, 230, 120))):
                pygame.draw.ellipse(s, kleur, (hx + 18 + i * 6, self.vloer - 50 + i * 12, 34 - i * 12, 50 - i * 12))
        else:
            stoel = rng.choice(((200, 70, 70), (70, 120, 200), (90, 160, 90)))
            pygame.draw.rect(s, stoel, (hx - 5, self.vloer - 70, 80, 45), border_radius=10)
            pygame.draw.rect(s, stoel, (hx - 5, self.vloer - 110, 22, 85), border_radius=8)
            pygame.draw.rect(s, c.mengkleur(stoel, c.ZWART, 0.3), (hx, self.vloer - 25, 8, 25))
            pygame.draw.rect(s, c.mengkleur(stoel, c.ZWART, 0.3), (hx + 62, self.vloer - 25, 8, 25))
        # schilderijtje
        pygame.draw.rect(s, (120, 80, 40), (pui.left + 6, boven + 35, 46, 36))
        pygame.draw.rect(s, (120, 190, 240), (pui.left + 11, boven + 40, 36, 26))
        pygame.draw.circle(s, (255, 220, 80), (pui.left + 38, boven + 47), 5)
        return s


# ---------------------------------------------------------------- het spel

class KadoSpel(c.Scene):
    def __init__(self):
        super().__init__()
        rng = random.Random()
        self.lucht = maak_lucht()
        self.achter = self.maak_achtergrond()
        self.tuin = self.maak_tuin()
        # steeds een ander soort huis naast elkaar
        soorten = []
        while len(soorten) < AANTAL:
            rij = SOORTEN[:]
            rng.shuffle(rij)
            if soorten and rij[0] == soorten[-1]:
                rij.reverse()
            soorten += rij
        self.huizen = [Huis(i, soorten[i], rng) for i in range(AANTAL)]
        # een paar huizen hebben al een cadeautje; het eerste huis heeft er nog geen
        for h in self.huizen[1:]:
            h.vol = rng.random() < 0.35
        self.pak = random.choice(PIET_PAKKEN)
        self.huid = random.choice(PIET_HUID)
        self.sint_img = pygame.transform.rotozoom(maak_sint(), 0, 0.45)
        self.sint_img_l = pygame.transform.flip(self.sint_img, True, False)
        self.sint_x = self.raam_x(self.huizen[0])
        self.sint_richting = 1
        self.sint_hup = 0.0

        self.x = 250.0
        self.y = float(GROND)
        self.richting = 1
        self.loop_fase = 0.0
        self.loop_tijd = 0.0
        self.toestand = "lopen"       # lopen / springen / wachten / binnen / terug
        self.t = 0.0
        self.vorig_t = 0.0
        self.huis = None              # het huis waar Piet nu een cadeautje brengt
        self.manier = None
        self.manier_nr = 0
        self.van = (0.0, 0.0)         # beginpunt van een sprong
        self.naar = (0.0, 0.0)        # eindpunt van een sprong
        self.door = False             # spatie al ingedrukt tijdens de sprong
        self.binnen_laag = False      # Piet is binnen (achter het glas)
        self.knip = None              # Piet wordt afgeknipt boven deze y (schoorsteen)
        self.draagt = False
        self.hop_t = None             # gewoon even springen op de plek

        self.cam = 0.0
        self.tijd = 0.0
        self.gebracht = 0
        self.feest_t = None
        self.actief_l = self.actief_r = 0.0
        self.deeltjes = c.Deeltjes()
        self.popups = c.Popups()
        self.sneeuw = [[random.uniform(0, W), random.uniform(0, H), random.uniform(30, 70), random.uniform(2, 4)]
                       for _ in range(60)]
        self.s_boing = boing()
        self.s_hoi = hoi()
        self.s_pling = c.pling()
        self.s_blij = c.blij_deuntje()
        self.s_fanfare = fanfare()
        self.s_schuif = schuif()
        self.s_piep = piep()
        self.s_omlaag = glij_omlaag()
        self.s_omhoog = glij_omhoog()
        self.s_plop = c.plop(1.3)

    # ---------------------------------------------------------------- wereld

    @staticmethod
    def maak_achtergrond():
        breedte = int((WERELD - W) * 0.35) + W
        s = pygame.Surface((breedte, H), pygame.SRCALPHA)
        rng = random.Random(8)
        x = -30
        while x < breedte:
            w = rng.randint(120, 200)
            top = GROND - rng.randint(250, 400)
            kleur = (30, 32, 62)
            pygame.draw.rect(s, kleur, (x, top, w, GROND - top))
            if rng.random() < 0.7:
                pygame.draw.polygon(s, kleur, [(x, top), (x + w / 2, top - 55), (x + w, top)])
            pygame.draw.rect(s, kleur, (x + w * 0.7, top - 60, 18, 60))
            for wy in range(top + 25, GROND - 50, 55):
                for wx in range(x + 20, x + w - 30, 45):
                    if rng.random() < 0.5:
                        pygame.draw.rect(s, (255, 215, 110), (wx, wy, 18, 24))
            x += w + rng.randint(5, 30)
        return s

    @staticmethod
    def maak_tuin():
        s = pygame.Surface((WERELD, H), pygame.SRCALPHA)
        pygame.draw.rect(s, (45, 105, 60), (0, GROND, WERELD, H - GROND))
        rng = random.Random(3)
        for _ in range(500):
            x, y = rng.uniform(0, WERELD), rng.uniform(GROND + 4, H)
            pygame.draw.line(s, (60, 130, 75), (x, y), (x + rng.uniform(-4, 4), y - 9), 3)
        # schuttingen tussen de tuinen, met hier en daar een struikje
        for i in range(AANTAL + 1):
            sx = huis_x(i) - AFSTAND / 2
            for p in range(-2, 3):
                px = sx + p * 22
                pygame.draw.rect(s, (130, 90, 55), (px - 10, GROND - 120, 20, 120))
                pygame.draw.polygon(s, (130, 90, 55), [(px - 10, GROND - 120), (px, GROND - 132), (px + 10, GROND - 120)])
                pygame.draw.rect(s, (105, 70, 40), (px - 10, GROND - 120, 20, 120), 2)
            pygame.draw.rect(s, (105, 70, 40), (sx - 56, GROND - 95, 112, 10))
            pygame.draw.rect(s, (105, 70, 40), (sx - 56, GROND - 40, 112, 10))
            if i % 2 == 0:
                for _ in range(9):
                    pygame.draw.circle(s, (55, 140, 70), (sx + rng.uniform(-70, 70), GROND - rng.uniform(10, 50)),
                                       rng.uniform(16, 26))
        return s

    @staticmethod
    def raam_x(h):
        return h.links + h.raam.centerx

    def dak_y(self, x):
        """Hoogte van de daken op wereld-x; tussen twee huizen springt Sint over (boogje)."""
        for h in self.huizen:
            if abs(x - h.x) <= HUIS_B / 2:
                return h.dak_wereld(x)
        links = [h for h in self.huizen if h.x < x]
        rechts = [h for h in self.huizen if h.x > x]
        if not links:
            return rechts[0].dak_wereld(rechts[0].links)
        if not rechts:
            return links[-1].dak_wereld(links[-1].links + HUIS_B)
        a, b = links[-1], rechts[0]
        x0, x1 = a.x + HUIS_B / 2, b.x - HUIS_B / 2
        k = (x - x0) / (x1 - x0)
        return c.lerp(a.dak_wereld(x0), b.dak_wereld(x1), k) - math.sin(math.pi * k) * 70

    def huis_bij(self, x, marge=190):
        for h in self.huizen:
            if abs(x - h.x) < marge:
                return h
        return None

    def leeg_huis_hier(self):
        h = self.huis_bij(self.x)
        return h if h is not None and not h.vol else None

    def doel_huis(self):
        """Het dichtstbijzijnde huis met een lege schoen."""
        lege = [h for h in self.huizen if not h.vol]
        if not lege or self.feest_t is not None:
            return None
        return min(lege, key=lambda h: abs(h.x - self.x))

    def hint_richting(self):
        h = self.doel_huis()
        if h is None or abs(h.x - self.x) < 150:
            return 0
        return 1 if h.x > self.x else -1

    # ---------------------------------------------------------------- invoer

    def handle(self, e):
        if e.type != pygame.KEYDOWN:
            return
        if e.key in ACTIE:
            self.actie()
            return
        k = c.toets(e)
        if k in ("links", "rechts"):
            r = -1 if k == "links" else 1
            if k == "links":
                self.actief_l = 1.0
            else:
                self.actief_r = 1.0
            if self.toestand == "lopen":
                self.richting = r
                self.loop_tijd = 0.35
            elif self.toestand == "wachten":
                # toch niet: Piet springt weer naar beneden
                self.spring(self.x + r * 60, GROND, "terug")
                self.richting = r

    def actie(self):
        if self.toestand == "lopen":
            h = self.leeg_huis_hier()
            if h is not None and self.feest_t is None:
                self.huis = h
                self.manier = MANIEREN[self.manier_nr % len(MANIEREN)]
                self.manier_nr += 1
                self.door = False
                self.draagt = True
                self.spring(*h.wereld(*h.wacht[self.manier]), "springen")
                self.s_boing.play()
            elif self.hop_t is None:
                self.hop_t = 0.0
                self.s_boing.play()
        elif self.toestand == "springen":
            self.door = True
        elif self.toestand == "wachten":
            self.naar_binnen()

    def spring(self, nx, ny, toestand):
        self.van = (self.x, self.y)
        self.naar = (nx, ny)
        self.toestand, self.t = toestand, 0.0
        if nx != self.x:
            self.richting = 1 if nx > self.x else -1

    def naar_binnen(self):
        self.toestand, self.t = "binnen", 0.0
        self.s_hoi.play()
        if self.manier == "schuifpui":
            self.s_schuif.play()
        elif self.manier == "raam":
            self.s_piep.play()

    # ---------------------------------------------------------------- update

    def update(self, dt):
        self.tijd += dt
        self.vorig_t = self.t
        self.t += dt
        if self.toestand == "lopen":
            self.update_lopen(dt)
        elif self.toestand in ("springen", "terug"):
            k = c.klem(self.t / SPRONG)
            hoogte = 110 if self.toestand == "springen" else 70
            self.x = c.lerp(self.van[0], self.naar[0], c.ease_in_out(k))
            self.y = c.lerp(self.van[1], self.naar[1], k) - math.sin(math.pi * k) * hoogte
            if k >= 1:
                self.x, self.y = self.naar
                if self.toestand == "springen":
                    self.toestand, self.t = "wachten", 0.0
                    self.s_plop.play()
                    if self.door:
                        self.naar_binnen()
                else:
                    self.toestand, self.t = "lopen", 0.0
                    self.huis = None
                    self.draagt = False
        elif self.toestand == "binnen":
            self.update_binnen(dt)

        if self.hop_t is not None:
            self.hop_t += dt
            if self.hop_t > SPRONG:
                self.hop_t = None

        for h in self.huizen:
            h.pop_t += dt
            if h.roet_t is not None:
                h.roet_t += dt
                if h.roet_t > 1.2:
                    h.roet_t = None
            # raam en pui gaan vanzelf weer dicht als Piet er niet mee bezig is
            if h is not self.huis or self.toestand != "binnen":
                h.raam_open = max(0.0, h.raam_open - dt * 2.5)
                h.pui_open = max(0.0, h.pui_open - dt * 2.5)

        self.cam += (c.klem(self.x - W / 2, 0, WERELD - W) - self.cam) * min(1.0, dt * 5)
        self.update_sint(dt)
        self.update_feest(dt)
        for f in self.sneeuw:
            f[1] += f[2] * dt
            f[0] += math.sin(self.tijd + f[1] * 0.01) * 15 * dt
            if f[1] > H:
                f[1], f[0] = -5, random.uniform(0, W)
        self.actief_l = max(0.0, self.actief_l - dt * 4)
        self.actief_r = max(0.0, self.actief_r - dt * 4)
        self.deeltjes.update(dt)
        self.popups.update(dt)

    def update_lopen(self, dt):
        links, rechts = c.vast_links(), c.vast_rechts()
        if links and not rechts:
            self.richting, self.loop_tijd = -1, max(self.loop_tijd, 0.05)
        elif rechts and not links:
            self.richting, self.loop_tijd = 1, max(self.loop_tijd, 0.05)
        if self.loop_tijd > 0:
            self.loop_tijd -= dt
            self.x = c.klem(self.x + self.richting * SNELHEID * dt, 120, WERELD - 120)
            self.loop_fase += dt * 12
        self.y = GROND

    def moment(self, tijdstip):
        """Is tijdstip in deze frame gepasseerd?"""
        return self.vorig_t < tijdstip <= self.t

    def update_binnen(self, dt):
        h, t, m = self.huis, self.t, self.manier
        wx = h.wereld
        self.knip = None
        if m == "schoorsteen":
            top_x, top_y = wx(h.schoorsteen.centerx, h.schoorsteen.top)
            start = wx(*h.wacht[m])
            diep = top_y + 175
            if t < 0.4:                                   # op de schoorsteen springen
                k = t / 0.4
                self.x = c.lerp(start[0], top_x, k)
                self.y = c.lerp(start[1], top_y, k) - math.sin(math.pi * k) * 60
            elif t < 0.9:                                 # erin zakken
                self.x, self.y = top_x, c.lerp(top_y, diep, c.ease_in((t - 0.4) / 0.5))
                self.knip = top_y
            elif t < 2.0:                                 # binnen: niet te zien
                if h.roet_t is None and t < 1.0:
                    h.roet_t = 0.0
                self.x, self.y, self.knip = top_x, diep, top_y
            else:                                         # weer omhoog
                self.x, self.y = top_x, c.lerp(diep, top_y, c.ease_out(c.klem((t - 2.0) / 0.4)))
                self.knip = top_y
            self.binnen_laag = False
            if self.moment(0.4):
                self.s_omlaag.play()
            if self.moment(2.0):
                self.s_omhoog.play()
        elif m == "raam":
            buiten = wx(*h.wacht[m])
            binnen = wx(h.schoen_x + 20, h.vloer)
            h.raam_open = c.klem(t / 0.4) if t < 2.1 else 1 - c.klem((t - 2.1) / 0.35)
            if t < 0.4:
                self.x, self.y, self.binnen_laag = buiten[0], buiten[1], False
            elif t < 0.65:                                # opstappen
                k = (t - 0.4) / 0.25
                self.x, self.y, self.binnen_laag = buiten[0], buiten[1] - math.sin(math.pi * k / 2) * 40, False
            elif t < 0.95:                                # naar binnen zakken
                k = (t - 0.65) / 0.3
                self.x = c.lerp(buiten[0], binnen[0], k)
                self.y, self.binnen_laag = c.lerp(buiten[1] - 40, binnen[1], c.ease_in(k)), True
            elif t < 1.6:
                self.x, self.y, self.binnen_laag = binnen[0], binnen[1], True
            elif t < 1.85:                                # omhoog klimmen
                k = (t - 1.6) / 0.25
                self.x, self.y, self.binnen_laag = binnen[0], c.lerp(binnen[1], buiten[1] - 40, c.ease_out(k)), True
            else:                                         # weer op de vensterbank
                k = c.klem((t - 1.85) / 0.25)
                self.x, self.y, self.binnen_laag = buiten[0], c.lerp(buiten[1] - 40, buiten[1], k), False
            if self.moment(2.1):
                self.s_piep.play()
        else:  # schuifpui
            deur = wx(*h.wacht[m])
            schoen = wx(h.schoen_x + (30 if not h.spiegel else -30), h.vloer)
            h.pui_open = c.klem(t / 0.5) if t < 3.0 else 1 - c.klem((t - 3.0) / 0.5)
            if t < 0.5:
                self.x, self.binnen_laag = deur[0], False
            elif t < 0.75:
                self.x, self.binnen_laag = deur[0], True
            elif t < 1.55:                                # naar de vensterbank lopen
                self.x = c.lerp(deur[0], schoen[0], (t - 0.75) / 0.8)
                self.richting = 1 if schoen[0] > deur[0] else -1
                self.loop_fase += dt * 12
            elif t < 2.2:
                self.x = schoen[0]
            elif t < 3.0:                                 # terug naar de deur
                self.x = c.lerp(schoen[0], deur[0], (t - 2.2) / 0.8)
                self.richting = 1 if deur[0] > schoen[0] else -1
                self.loop_fase += dt * 12
            else:
                self.x, self.binnen_laag = deur[0], False
            self.y = deur[1]
            if self.moment(3.0):
                self.s_schuif.play()

        if self.draagt and t >= KADO_MOMENT[m]:
            self.kado_erin(h)
        if t >= DUUR[m]:
            self.knip = None
            self.binnen_laag = False
            if m == "schuifpui":
                uit = self.x + (70 if h.pui.centerx > h.raam.centerx else -70)
            else:
                uit = h.x + (1 if self.x > h.x else -1) * 40
            self.spring(c.klem(uit, h.x - 230, h.x + 230), GROND, "terug")

    def kado_erin(self, h):
        self.draagt = False
        h.vol = True
        h.pop_t = 0.0
        self.gebracht += 1
        self.s_pling.play()
        self.s_blij.play()
        x, y = h.wereld(h.schoen_x, h.bank_y - 30)
        self.deeltjes.burst(x - self.cam, y, 40, [(255, 230, 90), c.WIT, (255, 150, 170)], 420, "ster")
        self.popups.voeg("Cadeautje!", h.x - self.cam, h.top - 20, (255, 220, 80), 64, 1.8)
        self.sint_hup = 1.0

    def update_sint(self, dt):
        doel = self.doel_huis()
        if doel is not None:
            dx = self.raam_x(doel)             # boven het raam met de lege schoen
        else:
            dx = self.x                        # niets meer te doen: loop gewoon mee met Piet
        dx = c.klem(dx, EERSTE - 150, huis_x(AANTAL - 1) + 150)   # Sint blijft op de daken
        verschil = dx - self.sint_x
        if abs(verschil) > 4:
            stap = min(abs(verschil), 300 * dt) * (1 if verschil > 0 else -1)
            self.sint_x += stap
            self.sint_richting = 1 if verschil > 0 else -1
        else:
            self.sint_richting = 1 if self.x > self.sint_x else -1
        self.sint_hup = max(0.0, self.sint_hup - dt * 1.5)

    def update_feest(self, dt):
        if self.feest_t is None:
            if all(h.vol for h in self.huizen) and self.toestand in ("lopen", "terug"):
                self.feest_t = 0.0
                self.s_fanfare.play()
                self.popups.voeg("Alle schoenen vol!", W // 2, 200, (255, 220, 80), 72, 3.5)
            return
        self.feest_t += dt
        if random.random() < dt * 6:
            self.deeltjes.burst(random.uniform(100, W - 100), random.uniform(60, 300), 30, snelheid=500)
        if self.feest_t > 6.0 and self.toestand == "lopen":
            self.feest_t = None
            # een nieuwe nacht: weer een paar lege schoenen, ook eentje vlakbij
            for h in self.huizen:
                h.vol = random.random() < 0.35
                h.kado = random.choice(KADO_KLEUREN)
            min(self.huizen, key=lambda h: abs(h.x - self.x) if abs(h.x - self.x) > 150 else 9e9).vol = False
            self.popups.voeg("Nieuwe nacht!", W // 2, 200, c.WIT, 64, 2.0)

    # ---------------------------------------------------------------- tekenen

    def teken_piet_nu(self, s):
        x = self.x - self.cam
        y = self.y
        lopen = self.toestand == "lopen" and self.loop_tijd > 0
        if self.toestand == "lopen":
            if lopen:
                y -= abs(math.sin(self.loop_fase)) * 8
            if self.hop_t is not None:
                y -= math.sin(math.pi * self.hop_t / SPRONG) * 90
        if self.toestand == "wachten":
            y -= abs(math.sin(self.t * 5)) * 8
        armen = self.draagt or self.toestand in ("springen", "wachten") or self.hop_t is not None
        if self.knip is not None:
            s.set_clip(pygame.Rect(0, 0, W, int(self.knip)))
        loopt_binnen = self.toestand == "binnen" and self.manier == "schuifpui" and (0.75 < self.t < 1.55
                                                                                       or 2.2 < self.t < 3.0)
        teken_piet(s, x, y, self.pak, self.huid, self.richting, self.loop_fase,
                   lopen or loopt_binnen, armen_omhoog=armen, S=S)
        if self.draagt and self.huis is not None:
            teken_kado(s, x, y - 196 * S, 17, self.huis.kado)
        if self.knip is not None:
            s.set_clip(None)

    def teken_huis(self, s, h):
        lx = h.links - self.cam
        if lx > W + 50 or lx + HUIS_B < -50:
            return
        top = h.top
        bezig = h is self.huis and self.toestand != "lopen"
        s.blit(h.binnen, (lx, top))
        if bezig and self.binnen_laag:
            self.teken_piet_nu(s)
        # binnenvensterbank met de schoen
        raam = h.raam.move(lx, top)
        pygame.draw.rect(s, (240, 240, 245), (raam.left - 6, top + h.bank_y, raam.width + 12, 14))
        pygame.draw.rect(s, (210, 210, 220), (raam.left - 6, top + h.bank_y + 14, raam.width + 12, 30))
        sx, sy = lx + h.schoen_x, top + h.bank_y
        teken_schoen(s, sx, sy)
        if h.vol:
            k = c.ease_out_back(c.klem(h.pop_t / 0.4))
            if k > 0.05:
                teken_kado(s, sx - 16, sy - 36, 17 * k, h.kado)
        else:
            # leeg plekje: een knipperend stippel-cadeautje met sterretjes
            gloed = 0.5 + 0.5 * math.sin(self.tijd * 5 + h.nr)
            r = pygame.Rect(0, 0, 40, 34)
            r.midbottom = (sx - 16, sy - 36)
            kleur = c.mengkleur((255, 200, 40), c.WIT, gloed)
            hoeken = [(r.left, r.top), (r.right, r.top), (r.right, r.bottom), (r.left, r.bottom)]
            for i in range(4):
                (x0, y0), (x1, y1) = hoeken[i], hoeken[(i + 1) % 4]
                for j in range(5):
                    a, b = j / 5, (j + 0.5) / 5
                    pygame.draw.line(s, kleur, (c.lerp(x0, x1, a), c.lerp(y0, y1, a)),
                                     (c.lerp(x0, x1, b), c.lerp(y0, y1, b)), 4)
            for i in range(3):
                a = self.tijd * 2 + i * 2.1 + h.nr
                pygame.draw.polygon(s, (255, 230, 90), c.sterpunten(r.centerx + math.cos(a) * 34,
                                                                    r.centery + math.sin(a) * 22, 7 + 3 * gloed, 3))
        # cadeautje valt door de schoorsteen naar beneden
        if bezig and self.manier == "schoorsteen" and self.toestand == "binnen" and 1.3 < self.t < KADO_MOMENT["schoorsteen"]:
            k = (self.t - 1.3) / (KADO_MOMENT["schoorsteen"] - 1.3)
            teken_kado(s, sx - 16, c.lerp(raam.top - 30, sy - 36, k * k), 17, h.kado)

        # ruiten, dan de gevel eroverheen
        open_b = raam.width * math.cos(h.raam_open * 1.35)
        if not h.spiegel:
            teken_glas(s, raam.left, raam.top, raam.width, raam.height, h.kozijn, open_b, roede=True)
        else:
            teken_glas(s, raam.right - open_b, raam.top, raam.width, raam.height, h.kozijn, open_b, roede=True)
        self.teken_pui(s, h, lx, top)
        s.blit(h.gevel, (lx, top))
        # slapende kindjes: zzz
        for zx, zy in h.zzz:
            for i in range(3):
                f = (self.tijd * 0.6 + i / 3) % 1
                c.tekst(s, "z", int(14 + f * 14), c.WIT, (lx + zx + f * 30, top + zy - f * 30), rand=(70, 80, 140), dikte=2)
        # roetwolkje uit de schoorsteen
        if h.roet_t is not None:
            k = h.roet_t / 1.2
            sch = h.schoorsteen
            for i in range(4):
                pygame.draw.circle(s, c.mengkleur((90, 90, 100), (40, 40, 70), k),
                                   (lx + sch.centerx + (i - 1.5) * 16 * (1 + k), top + sch.top - 10 - k * 70 - i % 2 * 10),
                                   14 + k * 14)
        # zachte gloed om het raam als de schoen nog leeg is
        if not h.vol:
            gloed = 0.5 + 0.5 * math.sin(self.tijd * 4 + h.nr)
            pygame.draw.rect(s, c.mengkleur((255, 200, 40), c.WIT, gloed), raam.inflate(30, 30), 6, border_radius=8)

    def teken_pui(self, s, h, lx, top):
        """Schuifpui: één vaste ruit en één ruit die opzij schuift (voor de vaste langs)."""
        pui = h.pui.move(lx, top)
        half = pui.width // 2
        open_ = c.ease_in_out(h.pui_open)
        if not h.spiegel:
            vast_x, schuif_x = pui.left + half, pui.left + open_ * (half - 8)
        else:
            vast_x, schuif_x = pui.left, pui.left + half - open_ * (half - 8)
        teken_glas(s, vast_x, pui.top, half, pui.height, ALU)
        teken_glas(s, schuif_x, pui.top, half, pui.height, ALU)
        greep_x = schuif_x + (half - 16 if not h.spiegel else 10)
        pygame.draw.rect(s, (200, 200, 210), (greep_x, pui.centery - 22, 7, 44), border_radius=3)
        pygame.draw.line(s, ALU, (pui.left, pui.bottom - 2), (pui.right, pui.bottom - 2), 5)   # rail

    def teken_sint(self, s):
        x = self.sint_x - self.cam
        if x < -150 or x > W + 150:
            return
        y = self.dak_y(self.sint_x) - math.sin(math.pi * self.sint_hup) * 50
        img = self.sint_img if self.sint_richting > 0 else self.sint_img_l
        s.blit(img, img.get_rect(midbottom=(x, y + 6)))
        doel = self.doel_huis()
        bezig = self.huis is doel and self.toestand != "lopen"
        if doel is not None and not bezig and abs(self.raam_x(doel) - self.sint_x) < 10:
            # Sint wijst naar het raam eronder
            bob = abs(math.sin(self.tijd * 5)) * 14
            ax = self.raam_x(doel) - self.cam
            ay = max(y + 40, doel.top + doel.raam.top - 66) + bob
            kleur = c.mengkleur((255, 220, 60), c.WIT, 0.5 + 0.5 * math.sin(self.tijd * 8))
            pts = [(ax - 14, ay - 26), (ax + 14, ay - 26), (ax + 14, ay), (ax + 28, ay), (ax, ay + 28), (ax - 28, ay),
                   (ax - 14, ay)]
            pygame.draw.polygon(s, kleur, pts)
            pygame.draw.polygon(s, c.ZWART, pts, 3)

    def teken_spatie(self, s, x, y):
        """Plaatje van de spatiebalk dat knippert: nu op spatie drukken!"""
        knip = 0.5 + 0.5 * math.sin(self.tijd * 8)
        bob = abs(math.sin(self.tijd * 4)) * 10
        r = pygame.Rect(0, 0, 170, 46)
        r.center = (x, y - bob)
        pygame.draw.rect(s, c.ZWART, r.move(4, 6), border_radius=12)
        pygame.draw.rect(s, c.mengkleur((255, 220, 60), c.WIT, knip * 0.6), r, border_radius=12)
        pygame.draw.rect(s, c.ZWART, r, 4, border_radius=12)
        pygame.draw.lines(s, c.ZWART, False, [(r.left + 45, r.centery - 6), (r.left + 45, r.centery + 6),
                                              (r.right - 45, r.centery + 6), (r.right - 45, r.centery - 6)], 4)

    def draw(self, s):
        s.blit(self.lucht, (0, 0))
        s.blit(self.achter, (-self.cam * 0.35, 0))
        s.blit(self.tuin, (-self.cam, 0))
        for h in self.huizen:
            self.teken_huis(s, h)
        self.teken_sint(s)
        if not self.binnen_laag:
            self.teken_piet_nu(s)

        # spatiebalk-hint bij Piet
        if self.feest_t is None:
            if self.toestand == "wachten":
                # naast Piet, aan de kant weg van Sint
                kant = 1 if self.x >= self.sint_x else -1
                hx = c.klem(self.x - self.cam + kant * 175, 260, W - 260)
                self.teken_spatie(s, hx, self.y - 90)
            elif self.toestand == "lopen" and self.leeg_huis_hier() is not None:
                self.teken_spatie(s, self.x - self.cam, GROND - 215)

        for x, y, _, r in self.sneeuw:
            pygame.draw.circle(s, c.WIT, (x, y), r)
        self.deeltjes.draw(s)
        self.popups.draw(s)
        self.teken_hud(s)

    def teken_hud(self, s):
        teken_kado(s, 50, 72, 22, KADO_KLEUREN[0])
        c.tekst(s, str(self.gebracht), 52, c.WIT, (110, 50))
        # onderaan in het gras: een rijtje schoenen, welke zijn al vol?
        breedte = 58
        x0 = W / 2 - (AANTAL - 1) * breedte / 2
        for i, h in enumerate(self.huizen):
            x = x0 + i * breedte
            pygame.draw.circle(s, (255, 220, 80) if h.vol else (35, 75, 45), (x, H - 38), 26)
            pygame.draw.circle(s, c.WIT, (x, H - 38), 26, 3)
            teken_schoen(s, x + 7, H - 20, 0.6)
            if h.vol:
                teken_kado(s, x - 3, H - 40, 10, h.kado)
        bob = math.sin(self.tijd * 5) * 6
        hint = self.hint_richting() if self.toestand == "lopen" else 0
        knipper = 0.5 + 0.5 * math.sin(self.tijd * 8)
        for richting, actief, x in ((-1, self.actief_l, 80), (1, self.actief_r, W - 80)):
            if richting == hint:
                c.pijl(s, (x, H // 2 + bob), richting, 60, (255, 220, 60), actief=max(actief, knipper * 0.8))
            else:
                c.pijl(s, (x, H // 2 + bob), richting, 38, (200, 200, 210), actief=actief)


if __name__ == "__main__":
    c.los_starten(KadoSpel)
