"""Tosti maken!

  links  = beleg erop (kaas, ham, tomaat, ...)
  rechts = boterham erop, in het tosti-ijzer, en daarna: happen!
"""
import math
import random

import pygame

from . import common as c
from .common import W, H

KORST = (196, 140, 72)
BINNEN = (250, 228, 180)
KORST_GETOOST = (140, 82, 30)
BINNEN_GETOOST = (230, 165, 75)
KAAS = (255, 208, 64)
KAAS_DONKER = (236, 170, 30)
HAM = (240, 140, 155)
HAM_LICHT = (252, 196, 204)
TOMAAT = (222, 48, 44)
TOMAAT_LICHT = (252, 120, 96)
IJZER = (210, 45, 50)
IJZER_DONKER = (140, 25, 35)
METAAL = (195, 200, 210)
HOUT = (205, 150, 95)
HOUT_DONKER = (165, 110, 65)

LAAG_HOOGTE = {"brood": 54, "kaas": 16, "ham": 18, "tomaat": 22, "dak": 60}
BELEG = ["kaas", "ham", "tomaat"]
NAMEN = {"kaas": "kaas", "ham": "ham", "tomaat": "tomaat", "dak": "brood"}

STAPEL_X = W // 2
BASIS_Y = 566
BREEDTE = 420
MAX_BELEG = 8

IJZER_B = 500
IJZER_X = W // 2 - IJZER_B // 2
PLAAT_Y = 540
DICHT_HOOGTE = 64
DEKSEL_L = IJZER_B - 16
DEKSEL_DIK = 62
OPEN_HOEK = 65
BAKTIJD = 4.5
IJZER_SCHAAL = 0.8

TOSTI_MIDDEN = (W // 2, 390)
EET_MAAT = 400

KAART_L = pygame.Rect(0, 0, 230, 250)
KAART_L.center = (170, 320)
KAART_R = pygame.Rect(0, 0, 230, 250)
KAART_R.center = (W - 170, 320)


def broodkleuren(toast):
    return c.mengkleur(KORST, KORST_GETOOST, toast), c.mengkleur(BINNEN, BINNEN_GETOOST, toast)


# ---------------------------------------------------------------- bovenaanzicht

def broodvorm(surf, kleur, rect):
    x, y, w, h = rect
    pygame.draw.ellipse(surf, kleur, (x, y, w, int(h * 0.55)))
    pygame.draw.rect(surf, kleur, (int(x + w * 0.06), int(y + h * 0.25), int(w * 0.88), int(h * 0.75)),
                     border_radius=int(w * 0.1))


def maak_tosti(grootte, toast=1.0, kaas=True, gezicht=False, seed=3):
    """Een tosti van bovenaf gezien, als plaatje met doorzichtige achtergrond."""
    rng = random.Random(seed)
    size = (grootte, grootte)
    s = pygame.Surface(size, pygame.SRCALPHA)
    m = int(grootte * 0.07)
    buiten = pygame.Rect(m, m, grootte - 2 * m, grootte - 2 * m)
    korst, binnen = broodkleuren(toast)

    if kaas:  # gesmolten kaas die er aan de randen uit komt
        for _ in range(8):
            kant = rng.choice("lro")
            r = grootte * rng.uniform(0.045, 0.07)
            if kant == "l":
                px, py = buiten.left + r * 0.3, rng.uniform(buiten.top + grootte * 0.35, buiten.bottom - grootte * 0.1)
            elif kant == "r":
                px, py = buiten.right - r * 0.3, rng.uniform(buiten.top + grootte * 0.35, buiten.bottom - grootte * 0.1)
            else:
                px, py = rng.uniform(buiten.left + grootte * 0.15, buiten.right - grootte * 0.15), buiten.bottom - r * 0.6
            pygame.draw.circle(s, KAAS, (px, py), r)
            pygame.draw.ellipse(s, KAAS, (px - r * 0.6, py, r * 1.2, r * 1.6))

    broodvorm(s, korst, buiten)
    binnenvlak = buiten.inflate(-int(grootte * 0.09), -int(grootte * 0.09))
    vlak = pygame.Surface(size, pygame.SRCALPHA)
    broodvorm(vlak, binnen, binnenvlak)
    if toast > 0.3:
        strepen = pygame.Surface(size, pygame.SRCALPHA)
        vlek = c.mengkleur(binnen, korst, 0.3)
        for _ in range(14):
            pygame.draw.circle(strepen, vlek, (rng.uniform(0, grootte), rng.uniform(0, grootte)),
                               rng.uniform(grootte * 0.03, grootte * 0.08))
        lijnkleur = c.mengkleur(binnen, korst, 0.8)
        for k in range(-4, 6):
            off = k * grootte * 0.17
            pygame.draw.line(strepen, lijnkleur, (off, 0), (off + grootte, grootte), max(3, int(grootte * 0.035)))
        vorm = pygame.Surface(size, pygame.SRCALPHA)
        broodvorm(vorm, (255, 255, 255, 255), binnenvlak)
        strepen.blit(vorm, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        vlak.blit(strepen, (0, 0))
    s.blit(vlak, (0, 0))
    if gezicht:
        c.gezichtje(s, grootte / 2, grootte * 0.58, grootte * 0.4)
    return s


def icoon(soort, maat=130):
    s = pygame.Surface((maat, maat), pygame.SRCALPHA)
    m = maat / 2
    if soort == "kaas":
        pts = [(m - 50, m - 45), (m + 50, m - 50), (m + 52, m + 45), (m - 48, m + 50)]
        pygame.draw.polygon(s, KAAS, pts)
        pygame.draw.polygon(s, KAAS_DONKER, pts, 4)
        for dx, dy, r in ((-20, -15, 11), (18, 5, 14), (-10, 25, 8), (25, -28, 7)):
            pygame.draw.circle(s, KAAS_DONKER, (m + dx, m + dy), r)
    elif soort == "ham":
        pygame.draw.circle(s, HAM, (m, m), 55)
        pygame.draw.circle(s, HAM_LICHT, (m, m), 55, 8)
        pygame.draw.circle(s, HAM_LICHT, (m + 12, m - 8), 12)
    elif soort == "tomaat":
        pygame.draw.circle(s, TOMAAT, (m, m + 6), 52)
        pygame.draw.circle(s, TOMAAT_LICHT, (m - 18, m - 10), 12)
        pygame.draw.polygon(s, (60, 160, 60), c.sterpunten(m, m - 42, 22, 9, 5))
    elif soort == "dak":
        b = maak_tosti(maat, toast=0.0, kaas=False)
        s.blit(b, (0, 0))
    return s


# ---------------------------------------------------------------- zijaanzicht

def teken_laag(surf, soort, cx, onder_y, breedte, toast=0.0, smelt=0.0):
    """Teken één laag van de tosti van opzij. Geeft de hoogte terug."""
    h = LAAG_HOOGTE[soort]
    x = cx - breedte / 2
    if soort in ("brood", "dak"):
        korst, binnen = broodkleuren(toast)
        r = pygame.Rect(int(x), int(onder_y - h), int(breedte), h)
        if soort == "dak":
            pygame.draw.rect(surf, korst, r, border_radius=14, border_top_left_radius=34, border_top_right_radius=34)
            pygame.draw.rect(surf, binnen, r.inflate(-14, -14), border_radius=10,
                             border_top_left_radius=28, border_top_right_radius=28)
        else:
            pygame.draw.rect(surf, korst, r, border_radius=16)
            pygame.draw.rect(surf, binnen, r.inflate(-14, -14), border_radius=10)
        if toast > 0.5:
            for i in range(6):
                gx = r.left + 40 + i * (r.width - 80) / 5
                pygame.draw.line(surf, korst, (gx, r.top + 8), (gx + 10, r.bottom - 8), 4)
    elif soort == "kaas":
        for dx in (-1, 1):  # druppels aan de zijkant
            ex = cx + dx * (breedte / 2 + 10)
            lengte = 16 + smelt * 28
            pygame.draw.ellipse(surf, KAAS, (ex - 10, onder_y - h + 2, 20, lengte + 10))
        pygame.draw.rect(surf, KAAS, (int(x - 18), int(onder_y - h), int(breedte + 36), h), border_radius=6)
        for i in range(5):
            pygame.draw.ellipse(surf, KAAS_DONKER, (x + 30 + i * breedte / 5, onder_y - h + 4, 16, 7))
    elif soort == "ham":
        pts = []
        for i in range(25):
            px = x - 8 + (breedte + 16) * i / 24
            pts.append((px, onder_y - h + 4 * math.sin(i * 1.3)))
        pts += [(x + breedte + 8, onder_y), (x - 8, onder_y)]
        pygame.draw.polygon(surf, HAM, pts)
        pygame.draw.line(surf, HAM_LICHT, (x, onder_y - h / 2), (x + breedte, onder_y - h / 2), 4)
    elif soort == "tomaat":
        sw = (breedte - 20) / 3
        for i in range(3):
            rx = x + 10 + i * sw
            rect = pygame.Rect(int(rx + 3), int(onder_y - h), int(sw - 6), h)
            pygame.draw.ellipse(surf, TOMAAT, rect)
            pygame.draw.ellipse(surf, TOMAAT_LICHT, rect.inflate(-20, -10))
            for j in range(3):
                pygame.draw.circle(surf, (255, 230, 150), (rect.left + 30 + j * (rect.width - 60) / 2, rect.centery), 3)
    return h


def deksel_punten(hx, hy, hoek):
    """Deksel van het tosti-ijzer met het scharnier rechts; hoek 0 = dicht."""
    a = math.radians(hoek)
    ca, sa = math.cos(a), math.sin(a)

    def rot(px, py):
        return (hx + px * ca - py * sa, hy + px * sa + py * ca)

    lijf = [rot(-DEKSEL_L, 0), rot(0, 0), rot(0, -DEKSEL_DIK), rot(-DEKSEL_L, -DEKSEL_DIK)]
    plaat = [rot(-DEKSEL_L + 12, 0), rot(-12, 0), rot(-12, -12), rot(-DEKSEL_L + 12, -12)]
    greep = [rot(-DEKSEL_L - 60, -42), rot(-DEKSEL_L + 5, -42), rot(-DEKSEL_L + 5, -18), rot(-DEKSEL_L - 60, -18)]
    return lijf, plaat, greep


def maak_keuken():
    s = c.verloop((255, 243, 224), (255, 222, 196), (W, H)).copy()
    for x in range(0, W, 80):
        pygame.draw.line(s, (240, 215, 190), (x, 0), (x, 560), 2)
    for y in range(0, 560, 80):
        pygame.draw.line(s, (240, 215, 190), (0, y), (W, y), 2)
    pygame.draw.rect(s, (170, 115, 75), (0, 560, W, H - 560))
    pygame.draw.rect(s, (195, 140, 95), (0, 560, W, 24))
    for x in range(0, W, 160):
        pygame.draw.line(s, (150, 100, 65), (x, 600), (x + 60, 700), 3)
    return s


# ---------------------------------------------------------------- het spel

class TostiSpel(c.Scene):
    def __init__(self):
        super().__init__()
        self.achtergrond = maak_keuken()
        self.deeltjes = c.Deeltjes()
        self.popups = c.Popups()
        self.iconen = {s: icoon(s) for s in BELEG + ["dak"]}
        self.s_plop = [c.plop(h) for h in (0.8, 1.0, 1.2)]
        self.s_sis = c.sissen()
        self.s_ding = c.ding()
        self.s_hap = c.hap()
        self.s_blij = c.blij_deuntje()
        self.s_klap = c.klap()
        self.s_zoef = c.zoef()
        self.s_nee = c.blip(300)
        self.tijd = 0.0
        self.nieuwe_tosti()

    # ---------------------------------------------------------------- toestand

    def nieuwe_tosti(self):
        self.fase = "beleggen"
        self.t = 0.0
        self.lagen = [{"soort": "brood", "van": BASIS_Y, "y": BASIS_Y, "doel": BASIS_Y, "t": 1.0}]
        self.volgend_beleg = 0
        self.wiebel_l = self.wiebel_r = 0.0
        self.actief_l = self.actief_r = 0.0
        self.kaart_uit = 0.0
        self.hoek = OPEN_HOEK
        self.smelt = 0.0
        self.stoomklok = 0.0
        self.eet_img = None
        self.hapjes = 0

    def aantal_beleg(self):
        return sum(1 for l in self.lagen if l["soort"] in BELEG)

    def top_y(self):
        l = self.lagen[-1]
        return l["doel"] - LAAG_HOOGTE[l["soort"]]

    def leg_erop(self, soort):
        self.lagen.append({"soort": soort, "van": -100, "y": -100, "doel": self.top_y(), "t": 0.0})
        random.choice(self.s_plop).play()

    def maak_stapelbeelden(self):
        totaal = sum(LAAG_HOOGTE[l["soort"]] for l in self.lagen)
        w, h = BREEDTE + 80, totaal + 60
        beelden = []
        for toast in (0.0, 1.0):
            img = pygame.Surface((w, h), pygame.SRCALPHA)
            y = h - 4
            for l in self.lagen:
                y -= teken_laag(img, l["soort"], w / 2, y, BREEDTE, toast=toast, smelt=toast)
            beelden.append(img)
        self.stapel_img, self.getoost_img = beelden

    # ---------------------------------------------------------------- invoer

    def handle(self, e):
        k = c.toets(e)
        if k is None:
            return
        f = self.fase
        if f == "beleggen":
            if k == "links":
                self.actief_l = 1.0
                if self.aantal_beleg() >= MAX_BELEG:
                    self.wiebel_r = 1.0
                    self.s_nee.play()
                    self.popups.voeg("Vol!", STAPEL_X, self.top_y() - 60, c.WIT, 70)
                else:
                    soort = BELEG[self.volgend_beleg]
                    self.volgend_beleg = (self.volgend_beleg + 1) % len(BELEG)
                    self.leg_erop(soort)
                    self.wiebel_l = 1.0
                    self.popups.voeg(NAMEN[soort] + "!", KAART_L.centerx, KAART_L.top - 30, c.WIT, 54)
            elif k == "rechts":
                self.actief_r = 1.0
                if self.aantal_beleg() == 0:
                    self.wiebel_l = 1.0
                    self.s_nee.play()
                else:
                    self.leg_erop("dak")
                    self.wiebel_r = 1.0
                    self.popups.voeg("brood!", KAART_R.centerx, KAART_R.top - 30, c.WIT, 54)
                    self.fase, self.t = "dichtvallen", 0.0
        elif f == "bakken":
            self.stoom(12)
            random.choice(self.s_plop).play()
        elif f == "klaar" and self.t > 0.9:
            self.fase, self.t = "eten", 0.0
            self.hap_nemen(-1 if k == "links" else 1)
        elif f == "eten":
            self.hap_nemen(-1 if k == "links" else 1 if k == "rechts" else random.choice((-1, 1)))
        elif f == "op" and self.t > 1.5:
            self.s_zoef.play()
            self.nieuwe_tosti()

    def stoom(self, n=1):
        bovenkant = PLAAT_Y - DICHT_HOOGTE - DEKSEL_DIK
        for _ in range(n):
            x = random.uniform(IJZER_X + 40, IJZER_X + IJZER_B - 40)
            self.deeltjes.burst(x, bovenkant, 1, [(245, 245, 250), (230, 232, 240)], 60, "stoom",
                                -140, 1.3, (10, 20), omhoog=1.0)

    def hap_nemen(self, kant):
        img = self.eet_img
        w, h = img.get_size()
        rect = img.get_rect(center=TOSTI_MIDDEN)
        hoek = random.uniform(-0.7, 0.7)
        dx, dy = kant * math.cos(hoek), math.sin(hoek)
        # loop van buiten naar het midden tot we tosti raken
        cx, cy = w / 2, h / 2
        rand = None
        for i in range(80):
            afstand = w * 0.75 * (1 - i / 80)
            px, py = int(cx + dx * afstand), int(cy + dy * afstand)
            if 0 <= px < w and 0 <= py < h and img.get_at((px, py)).a > 100:
                rand = (px, py)
                break
        if rand is None:
            rand = (int(cx), int(cy))
        r = w * 0.14
        bx, by = rand[0] + dx * r * 0.3, rand[1] + dy * r * 0.3
        leeg = (0, 0, 0, 0)
        pygame.draw.circle(img, leeg, (bx, by), r)
        for z in (-1, 1):  # tandafdrukjes
            pygame.draw.circle(img, leeg, (bx - dy * r * z * 0.85 + dx * r * 0.25, by + dx * r * z * 0.85 + dy * r * 0.25), r * 0.6)
        self.s_hap.play()
        sx, sy = rect.left + rand[0], rect.top + rand[1]
        self.deeltjes.burst(sx, sy, 18, [KORST_GETOOST, BINNEN_GETOOST, KAAS], 260, "kruimel", 900, 1.0, (5, 10))
        self.popups.voeg(random.choice(["Hap!", "Mmm!", "Nom!", "Hap!"]), sx, sy - 40, c.WIT, 60, 0.9)
        self.hapjes += 1
        over = pygame.mask.from_surface(img).count()
        if over < self.vol_pixels * 0.12 or self.hapjes >= 12:
            self.fase, self.t = "op", 0.0
            self.s_blij.play()
            self.deeltjes.burst(TOSTI_MIDDEN[0], TOSTI_MIDDEN[1], 70, snelheid=600)

    # ---------------------------------------------------------------- update

    def update(self, dt):
        self.tijd += dt
        self.t += dt
        f = self.fase
        self.wiebel_l = max(0.0, self.wiebel_l - dt * 2.5)
        self.wiebel_r = max(0.0, self.wiebel_r - dt * 2.5)
        self.actief_l = max(0.0, self.actief_l - dt * 4)
        self.actief_r = max(0.0, self.actief_r - dt * 4)
        for l in self.lagen:
            if l["t"] < 1:
                l["t"] = min(1.0, l["t"] + dt / 0.55)
                l["y"] = c.lerp(l["van"], l["doel"], c.ease_out_bounce(l["t"]))

        if f == "dichtvallen":
            self.kaart_uit = c.ease_in_out(self.t / 0.6)
            if self.t > 1.0:
                self.maak_stapelbeelden()
                self.fase, self.t = "schuiven", 0.0
                self.s_zoef.play()
        elif f == "schuiven":
            if self.t > 1.4:
                self.fase, self.t = "dichtklappen", 0.0
        elif f == "dichtklappen":
            self.hoek = OPEN_HOEK * (1 - c.ease_in(self.t / 0.45))
            if self.t > 0.45:
                self.hoek = 0
                self.s_klap.play()
                self.s_sis.play(loops=-1)
                self.fase, self.t = "bakken", 0.0
                self.stoom(10)
        elif f == "bakken":
            self.smelt = c.klem(self.t / BAKTIJD)
            self.stoomklok += dt
            if self.stoomklok > 0.12:
                self.stoomklok = 0
                self.stoom(1)
            if self.t > BAKTIJD:
                self.s_sis.stop()
                self.s_ding.play()
                self.popups.voeg("Ding!", W // 2, 120, (255, 220, 80), 80)
                self.fase, self.t = "openklappen", 0.0
        elif f == "openklappen":
            self.hoek = OPEN_HOEK * c.ease_out(self.t / 0.5)
            if self.t > 0.7:
                self.eet_img = maak_tosti(EET_MAAT, toast=1.0)
                self.vol_pixels = pygame.mask.from_surface(self.eet_img).count()
                self.fase, self.t = "klaar", 0.0
                self.s_blij.play()
        elif f == "klaar":
            if 0.8 < self.t < 0.8 + dt * 1.5:
                self.deeltjes.burst(TOSTI_MIDDEN[0], TOSTI_MIDDEN[1], 40, [(255, 230, 90), c.WIT], 500, "ster")
        elif f == "op":
            if random.random() < dt * 3:
                self.deeltjes.burst(random.uniform(100, W - 100), random.uniform(80, 300), 20)

        self.deeltjes.update(dt)
        self.popups.update(dt)

    # ---------------------------------------------------------------- tekenen

    def teken_plank(self, s, dx=0, dy=0):
        plank = pygame.Rect(0, 0, 600, 30)
        plank.midtop = (STAPEL_X + dx, BASIS_Y + dy)
        pygame.draw.rect(s, HOUT_DONKER, plank.move(0, 6), border_radius=10)
        pygame.draw.rect(s, HOUT, plank, border_radius=10)
        greep = pygame.Rect(plank.left - 60, plank.top + 6, 70, 18)
        pygame.draw.rect(s, HOUT, greep, border_radius=9)
        pygame.draw.circle(s, HOUT_DONKER, (greep.left + 16, greep.centery), 5)

    def teken_kaart(self, s, rect, img, label, wiebel, richting, actief, uitschuif, dim=False):
        r = rect.move(-richting * 0 + richting * uitschuif * 400, 0)
        hoek = math.sin(self.tijd * 30) * 8 * wiebel
        kaart = pygame.Surface(r.size, pygame.SRCALPHA)
        pygame.draw.rect(kaart, (255, 255, 255, 235), kaart.get_rect(), border_radius=28)
        pygame.draw.rect(kaart, (230, 200, 170), kaart.get_rect(), 6, border_radius=28)
        kaart.blit(img, img.get_rect(center=(r.width // 2, r.height // 2 - 18)))
        tl = c.lettertype(38).render(label, True, c.ZWART)
        kaart.blit(tl, tl.get_rect(center=(r.width // 2, r.height - 34)))
        if dim:
            kaart.set_alpha(120)
        if hoek:
            kaart = pygame.transform.rotozoom(kaart, hoek, 1.0)
        s.blit(kaart, kaart.get_rect(center=r.center))
        bob = math.sin(self.tijd * 5) * 6
        c.pijl(s, (r.centerx, r.bottom + 70 + bob), richting, 52, actief=actief)

    def teken_stapelbeeld(self, s, cx, onder, schaal, hoogte, toast):
        w = int(self.stapel_img.get_width() * schaal)
        hoogte = max(4, int(hoogte))
        for img, alpha in ((self.stapel_img, 255), (self.getoost_img, int(255 * toast))):
            if alpha <= 0:
                continue
            b = pygame.transform.smoothscale(img, (w, hoogte))
            b.set_alpha(alpha)
            s.blit(b, b.get_rect(midbottom=(cx, onder + 4 * schaal)))

    def teken_ijzer(self, s, x, dy, met_tosti):
        y = PLAAT_Y + dy
        for vx in (x + 40, x + IJZER_B - 90):
            pygame.draw.rect(s, (60, 60, 70), (vx, y + 70, 50, 20), border_radius=6)
        pygame.draw.rect(s, IJZER_DONKER, (x - 50, y + 22, 70, 22), border_radius=10)
        pygame.draw.rect(s, IJZER, (x, y, IJZER_B, 80), border_radius=24)
        pygame.draw.rect(s, METAAL, (x + 14, y - 8, IJZER_B - 28, 14), border_radius=5)
        klaar = self.fase not in ("bakken", "dichtklappen")
        lampje = (90, 220, 90) if klaar else ((255, 60, 60) if int(self.tijd * 4) % 2 else (180, 30, 30))
        pygame.draw.circle(s, c.WIT, (x + 60, y + 42), 15)
        pygame.draw.circle(s, lampje, (x + 60, y + 42), 11)
        hx, hy = x + IJZER_B - 10, y - DICHT_HOOGTE
        pygame.draw.rect(s, IJZER_DONKER, (hx - 18, hy - 12, 36, DICHT_HOOGTE + 24), border_radius=10)

        if met_tosti:
            self.teken_tosti_in_ijzer(s, x, dy)

        lijf, plaat, greep = deksel_punten(hx, hy, self.hoek)
        pygame.draw.polygon(s, IJZER_DONKER, greep)
        pygame.draw.polygon(s, IJZER, lijf)
        pygame.draw.polygon(s, IJZER_DONKER, lijf, 5)
        pygame.draw.polygon(s, METAAL, plaat)
        pygame.draw.circle(s, (80, 20, 25), (hx, hy), 14)

    def teken_tosti_in_ijzer(self, s, x, dy):
        cx = x + IJZER_B / 2
        onder = PLAAT_Y - 6 + dy
        nat_h = self.stapel_img.get_height() * IJZER_SCHAAL
        f = self.fase
        if f == "dichtklappen":
            h = c.lerp(nat_h, DICHT_HOOGTE - 6, c.ease_in(self.t / 0.45))
        elif f in ("bakken", "openklappen", "klaar"):
            h = DICHT_HOOGTE - 6
        else:
            h = nat_h
        self.teken_stapelbeeld(s, cx, onder, IJZER_SCHAAL, h, self.smelt)
        if f in ("bakken", "openklappen"):
            halve = BREEDTE * IJZER_SCHAAL / 2
            for kant in (-1, 1):
                lengte = 10 + 35 * self.smelt
                pygame.draw.ellipse(s, KAAS, (cx + kant * (halve + 14) - 11, onder - 34, 22, lengte + 14))

    def draw(self, s):
        s.blit(self.achtergrond, (0, 0))
        f = self.fase

        if f in ("beleggen", "dichtvallen"):
            self.teken_plank(s)
            wiebel = math.sin(self.tijd * 35) * 6 * self.wiebel_r if self.aantal_beleg() >= MAX_BELEG else 0
            for l in self.lagen:
                teken_laag(s, l["soort"], STAPEL_X + wiebel, l["y"], BREEDTE)
            volgend = BELEG[self.volgend_beleg]
            self.teken_kaart(s, KAART_L, self.iconen[volgend], NAMEN[volgend], self.wiebel_l, -1,
                             self.actief_l, self.kaart_uit)
            self.teken_kaart(s, KAART_R, self.iconen["dak"], "brood", self.wiebel_r, 1,
                             self.actief_r, self.kaart_uit, dim=self.aantal_beleg() == 0)

        elif f == "schuiven":
            t = self.t
            self.teken_plank(s, dx=-900 * c.ease_in(t / 0.5))
            ijzer_x = IJZER_X + (1 - c.ease_out((t - 0.2) / 0.6)) * 900
            self.teken_ijzer(s, ijzer_x, 0, False)
            nat_h = self.stapel_img.get_height()
            if t < 0.5:
                onder = BASIS_Y - 260 * c.ease_out(t / 0.5)
                schaal = 1.0
            else:
                p = c.ease_in((t - 0.5) / 0.8)
                onder = c.lerp(BASIS_Y - 260, PLAAT_Y - 6, p)
                schaal = c.lerp(1.0, IJZER_SCHAAL, p)
            self.teken_stapelbeeld(s, STAPEL_X, onder, schaal, nat_h * schaal, 0)

        elif f in ("dichtklappen", "bakken", "openklappen"):
            self.teken_ijzer(s, IJZER_X, 0, True)

        elif f == "klaar":
            p = c.ease_in_out(self.t / 0.8)
            self.teken_ijzer(s, IJZER_X, p * 900, p < 0.05)
            self.teken_bord(s, p)
            k = c.ease_out_back(self.t / 0.8)
            maat = max(10, int(EET_MAAT * c.lerp(0.3, 1.0, k)))
            img = pygame.transform.smoothscale(self.eet_img, (maat, maat))
            y = c.lerp(PLAAT_Y - 40, TOSTI_MIDDEN[1], c.ease_out(self.t / 0.8))
            s.blit(img, img.get_rect(center=(TOSTI_MIDDEN[0], y)))
            if self.t > 0.9:
                c.tekst(s, "Klaar!", 90, (255, 220, 80), (W // 2, 90 + math.sin(self.tijd * 5) * 8))
                self.teken_hap_pijlen(s)

        elif f == "eten":
            self.teken_bord(s, 1)
            s.blit(self.eet_img, self.eet_img.get_rect(center=TOSTI_MIDDEN))
            self.teken_hap_pijlen(s)

        elif f == "op":
            self.teken_bord(s, 1)
            self.teken_smikkel(s)
            if self.t > 1.5:
                self.teken_hap_pijlen(s)

        self.deeltjes.draw(s)
        self.popups.draw(s)

    def teken_bord(self, s, p):
        if p <= 0:
            return
        r = int(260 * c.ease_out_back(p))
        cx, cy = TOSTI_MIDDEN
        pygame.draw.circle(s, (210, 210, 220), (cx, cy + 10), r)
        pygame.draw.circle(s, c.WIT, (cx, cy), r)
        pygame.draw.circle(s, (235, 235, 245), (cx, cy), int(r * 0.75), 6)

    def teken_hap_pijlen(self, s):
        bob = math.sin(self.tijd * 5) * 6
        c.pijl(s, (TOSTI_MIDDEN[0] - 380, TOSTI_MIDDEN[1] + bob), -1, 55)
        c.pijl(s, (TOSTI_MIDDEN[0] + 380, TOSTI_MIDDEN[1] + bob), 1, 55)

    def teken_smikkel(self, s):
        cx, cy = TOSTI_MIDDEN
        k = c.ease_out_back(self.t / 0.5)
        r = max(5, int(150 * k))
        pygame.draw.circle(s, (255, 215, 60), (cx, cy), r)
        pygame.draw.circle(s, (230, 170, 30), (cx, cy), r, 6)
        if k > 0.5:
            c.gezichtje(s, cx, cy - r * 0.15, r * 1.2, ogen_dicht=True)
            tong = math.sin(self.tijd * 6) * 20
            pygame.draw.ellipse(s, (240, 90, 110), (cx - 25 + tong, cy + r * 0.25, 50, 40))
        c.tekst(s, "Mmm, lekker!", 80, (255, 220, 80), (W // 2, 90 + math.sin(self.tijd * 5) * 8))


if __name__ == "__main__":
    c.los_starten(TostiSpel)
