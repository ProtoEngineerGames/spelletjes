"""Stickeren!

  links  = kies een andere sticker
  rechts = plak de sticker
Als de bladzijde vol is, komt er een nieuwe bladzijde.
"""
import math
import random

import pygame

from . import common as c
from .common import W, H
from . import tosti

BASIS = 160
RAND = 7
PER_BLAD = 15
LADE_Y = H - 75


def _leeg():
    return pygame.Surface((BASIS, BASIS), pygame.SRCALPHA)


def hartpunten(cx, cy, maat):
    pts = []
    for i in range(60):
        t = 2 * math.pi * i / 60
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((cx + x * maat / 34, cy + y * maat / 34))
    return pts


def s_ster():
    s = _leeg()
    pygame.draw.polygon(s, (255, 200, 40), c.sterpunten(80, 86, 78, 38))
    pygame.draw.polygon(s, (255, 225, 110), c.sterpunten(80, 86, 56, 27))
    c.gezichtje(s, 80, 92, 55)
    return s


def s_hart():
    s = _leeg()
    pygame.draw.polygon(s, (240, 50, 80), hartpunten(80, 72, 150))
    pygame.draw.ellipse(s, (255, 150, 170), (35, 40, 30, 20))
    c.gezichtje(s, 80, 80, 60)
    return s


def s_zon():
    s = _leeg()
    for i in range(12):
        a = i * math.pi / 6
        pts = [(80 + math.cos(a) * 78, 80 + math.sin(a) * 78),
               (80 + math.cos(a + 0.22) * 50, 80 + math.sin(a + 0.22) * 50),
               (80 + math.cos(a - 0.22) * 50, 80 + math.sin(a - 0.22) * 50)]
        pygame.draw.polygon(s, (255, 150, 30), pts)
    pygame.draw.circle(s, (255, 210, 50), (80, 80), 52)
    c.gezichtje(s, 80, 84, 60)
    return s


def s_bloem():
    s = _leeg()
    for i in range(6):
        a = i * math.pi / 3
        pygame.draw.circle(s, (240, 110, 200), (80 + math.cos(a) * 44, 80 + math.sin(a) * 44), 32)
    pygame.draw.circle(s, (255, 215, 60), (80, 80), 34)
    c.gezichtje(s, 80, 84, 42)
    return s


def s_tosti():
    s = _leeg()
    s.blit(tosti.maak_tosti(156, toast=0.8, gezicht=True), (2, 2))
    return s


def s_regenboog():
    s = _leeg()
    kleuren = [(240, 60, 60), (255, 150, 40), (255, 220, 50), (90, 200, 80), (60, 140, 230), (150, 90, 210)]
    for i, kl in enumerate(kleuren):
        pygame.draw.circle(s, kl, (80, 118), 76 - i * 10, 11, draw_top_left=True, draw_top_right=True)
    for wx in (22, 138):
        for dx, dy, r in ((-14, 4, 14), (0, -4, 18), (14, 4, 14)):
            pygame.draw.circle(s, (245, 248, 255), (wx + dx, 122 + dy), r)
    return s


def s_vlinder():
    s = _leeg()
    for k in (-1, 1):
        pygame.draw.ellipse(s, (150, 90, 220), (80 + k * 38 - 32, 22, 64, 66))
        pygame.draw.ellipse(s, (255, 120, 190), (80 + k * 32 - 24, 80, 48, 54))
        pygame.draw.circle(s, (255, 230, 120), (80 + k * 40, 55), 12)
        pygame.draw.line(s, c.ZWART, (80, 40), (80 + k * 22, 10), 3)
        pygame.draw.circle(s, c.ZWART, (80 + k * 22, 10), 5)
    pygame.draw.ellipse(s, (70, 50, 60), (70, 38, 20, 100))
    pygame.draw.circle(s, (70, 50, 60), (80, 40), 15)
    pygame.draw.circle(s, c.WIT, (75, 38), 3)
    pygame.draw.circle(s, c.WIT, (85, 38), 3)
    return s


def s_kat():
    s = _leeg()
    for k in (-1, 1):
        pygame.draw.polygon(s, (250, 165, 75), [(80 + k * 58, 70), (80 + k * 50, 14), (80 + k * 14, 42)])
        pygame.draw.polygon(s, c.ROZE, [(80 + k * 48, 58), (80 + k * 46, 28), (80 + k * 26, 44)])
    pygame.draw.circle(s, (250, 165, 75), (80, 90), 58)
    c.gezichtje(s, 80, 92, 70)
    pygame.draw.polygon(s, c.ROZE, [(74, 96), (86, 96), (80, 103)])
    for k in (-1, 1):
        for dy in (-6, 6):
            pygame.draw.line(s, c.ZWART, (80 + k * 22, 104), (80 + k * 62, 100 + dy), 2)
    return s


def s_ijsje():
    s = _leeg()
    pygame.draw.polygon(s, (230, 180, 110), [(46, 82), (114, 82), (80, 156)])
    for i in range(4):
        pygame.draw.line(s, (200, 145, 80), (52 + i * 16, 82), (80 + i * 6, 150), 3)
    pygame.draw.circle(s, (255, 160, 190), (80, 66), 42)
    for dx in (-30, -8, 16, 34):
        pygame.draw.circle(s, (255, 160, 190), (80 + dx, 88), 10)
    pygame.draw.line(s, (60, 130, 50), (80, 24), (90, 6), 3)
    pygame.draw.circle(s, (220, 30, 50), (80, 24), 11)
    c.gezichtje(s, 80, 70, 46)
    return s


def s_lieveheersbeestje():
    s = _leeg()
    pygame.draw.circle(s, c.ZWART, (80, 38), 26)
    pygame.draw.circle(s, (230, 40, 40), (80, 96), 58)
    pygame.draw.line(s, c.ZWART, (80, 40), (80, 152), 4)
    for dx, dy in ((-30, 75), (30, 75), (-36, 108), (36, 108), (-15, 132), (15, 132)):
        pygame.draw.circle(s, c.ZWART, (80 + dx, dy), 10)
    pygame.draw.circle(s, c.WIT, (70, 32), 7)
    pygame.draw.circle(s, c.WIT, (90, 32), 7)
    pygame.draw.circle(s, c.ZWART, (70, 33), 3)
    pygame.draw.circle(s, c.ZWART, (90, 33), 3)
    return s


def s_ballon():
    s = _leeg()
    pts = [(80 + math.sin(i / 3) * 6, 112 + i * 4) for i in range(12)]
    pygame.draw.lines(s, (90, 90, 100), False, pts, 3)
    pygame.draw.ellipse(s, (60, 150, 240), (34, 6, 92, 108))
    pygame.draw.polygon(s, (60, 150, 240), [(72, 118), (88, 118), (80, 108)])
    pygame.draw.ellipse(s, (170, 215, 255), (50, 24, 18, 28))
    c.gezichtje(s, 80, 62, 50)
    return s


def s_vis():
    s = _leeg()
    pygame.draw.polygon(s, (255, 130, 40), [(110, 80), (156, 44), (156, 116)])
    pygame.draw.ellipse(s, (255, 160, 50), (8, 38, 118, 84))
    pygame.draw.polygon(s, (255, 130, 40), [(60, 42), (90, 18), (95, 46)])
    for i in range(3):
        pygame.draw.arc(s, (255, 200, 120), (60 + i * 14, 56, 24, 48), -1.2, 1.2, 3)
    pygame.draw.circle(s, c.WIT, (40, 70), 12)
    pygame.draw.circle(s, c.ZWART, (38, 71), 6)
    pygame.draw.arc(s, c.ZWART, (22, 82, 24, 16), math.pi, 2 * math.pi, 3)
    return s


def s_paard():
    s = _leeg()
    pygame.draw.ellipse(s, (250, 250, 252), (30, 30, 100, 120))
    for k in (-1, 1):
        pygame.draw.polygon(s, (250, 250, 252), [(80 + k * 22, 40), (80 + k * 40, 6), (80 + k * 44, 44)])
        pygame.draw.polygon(s, c.ROZE, [(80 + k * 27, 38), (80 + k * 39, 16), (80 + k * 40, 40)])
    for i in range(6):
        pygame.draw.circle(s, (180, 180, 200), (64 + i * 7, 30 - (i % 2) * 6), 10)
    pygame.draw.ellipse(s, (255, 205, 210), (44, 100, 72, 48))
    pygame.draw.circle(s, (200, 140, 150), (68, 122), 5)
    pygame.draw.circle(s, (200, 140, 150), (92, 122), 5)
    c.gezichtje(s, 80, 78, 56)
    return s


MAKERS = [s_ster, s_hart, s_tosti, s_zon, s_bloem, s_regenboog, s_vlinder, s_kat,
          s_ijsje, s_lieveheersbeestje, s_ballon, s_vis, s_paard]


def stickerify(vorm):
    """Geef een vorm een witte sticker-rand en een schaduwtje."""
    w, h = vorm.get_size()
    rand = pygame.Surface((w + 2 * RAND, h + 2 * RAND), pygame.SRCALPHA)
    masker = pygame.mask.from_surface(vorm, 10)
    wit = masker.to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0))
    for r in (RAND, RAND * 0.5):
        for i in range(24):
            a = i * math.pi / 12
            rand.blit(wit, (RAND + math.cos(a) * r, RAND + math.sin(a) * r))
    rand.blit(wit, (RAND, RAND))
    schaduw = pygame.mask.from_surface(rand, 10).to_surface(setcolor=(0, 0, 0, 70), unsetcolor=(0, 0, 0, 0))
    uit = pygame.Surface((w + 2 * RAND + 5, h + 2 * RAND + 7), pygame.SRCALPHA)
    uit.blit(schaduw, (4, 6))
    uit.blit(rand, (0, 0))
    uit.blit(vorm, (RAND, RAND))
    return uit


_stickers = None


def alle_stickers():
    global _stickers
    if _stickers is None:
        _stickers = [stickerify(m()) for m in MAKERS]
    return _stickers


# ---------------------------------------------------------------- achtergronden

def bg_weide():
    s = c.verloop((140, 205, 255), (210, 240, 255), (W, H)).copy()
    pygame.draw.ellipse(s, (120, 200, 90), (-200, 380, 900, 500))
    pygame.draw.ellipse(s, (100, 185, 75), (500, 420, 1100, 500))
    for x, y in ((180, 110), (900, 80)):
        for dx, dy, r in ((-40, 10, 35), (0, -10, 45), (40, 10, 35)):
            pygame.draw.circle(s, c.WIT, (x + dx, y + dy), r)
    return s


def bg_zee():
    s = c.verloop((80, 190, 230), (20, 80, 160), (W, H)).copy()
    pygame.draw.ellipse(s, (240, 215, 150), (-100, 530, W + 200, 300))
    rng = random.Random(4)
    for _ in range(25):
        x, y, r = rng.uniform(0, W), rng.uniform(0, 500), rng.uniform(5, 15)
        pygame.draw.circle(s, (180, 230, 255), (x, y), r, 2)
    for x in (120, 1150):
        for i in range(5):
            pygame.draw.ellipse(s, (50, 160, 90), (x + math.sin(i) * 12, 580 - i * 45, 26, 60))
    return s


def bg_nacht():
    s = c.verloop((15, 20, 60), (60, 50, 120), (W, H)).copy()
    rng = random.Random(7)
    for _ in range(80):
        pygame.draw.circle(s, (255, 255, 220), (rng.uniform(0, W), rng.uniform(0, H)), rng.uniform(1, 3))
    pygame.draw.circle(s, (255, 245, 200), (1100, 110), 60)
    pygame.draw.circle(s, (15 + 10, 22, 65), (1130, 95), 55)
    return s


def bg_papier():
    s = pygame.Surface((W, H))
    s.fill((255, 248, 235))
    for y in range(40, H, 40):
        pygame.draw.line(s, (220, 230, 250), (0, y), (W, y), 2)
    pygame.draw.line(s, (250, 180, 180), (90, 0), (90, H), 3)
    return s


ACHTERGRONDEN = [bg_weide, bg_zee, bg_nacht, bg_papier]


class Geplakt:
    def __init__(self, idx, x, y, schaal, hoek):
        self.idx, self.x, self.y, self.schaal, self.hoek = idx, x, y, schaal, hoek
        self.t = 0.0
        self.beeld = None
        self.vlucht = None
        self.gebakken = False     # staat al vast in het blad-plaatje (hoeft niet elke keer getekend)

    def klaar(self):
        return self.t >= 0.35 and not self.vlucht

    def draw(self, s, stickers):
        if self.t < 0.35 or self.vlucht:
            k = c.ease_out_back(self.t / 0.35) if not self.vlucht else 1.0
            img = pygame.transform.rotozoom(stickers[self.idx], self.hoek, max(0.05, self.schaal * k))
        else:
            if self.beeld is None:
                self.beeld = c.snel(pygame.transform.rotozoom(stickers[self.idx], self.hoek, self.schaal))
            img = self.beeld
        s.blit(img, img.get_rect(center=(int(self.x), int(self.y))))


class StickerSpel(c.Scene):
    def __init__(self):
        super().__init__()
        self.stickers = [c.snel(st) for st in alle_stickers()]
        self.duimpjes = [c.snel(pygame.transform.smoothscale(st, (int(st.get_width() * 0.42),
                                                                  int(st.get_height() * 0.42))))
                         for st in self.stickers]
        self.achtergronden = [c.snel(maak()) for maak in ACHTERGRONDEN]
        self.blad_img = self.achtergronden[0].copy()   # achtergrond + vastgeplakte stickers
        # halfdoorzichtige lade: één keer maken (colorkey-hoeken + vaste alpha is snel)
        self.lade = c.snel(pygame.Surface((W - 20, 140)))
        self.lade.fill(c.SLEUTEL)
        pygame.draw.rect(self.lade, (255, 255, 255), self.lade.get_rect(), border_radius=30)
        self.lade.set_colorkey(c.SLEUTEL)
        self.lade.set_alpha(200)
        self.blad = 0
        self.geplakt = []
        self.vliegend = []
        self.keuze = 0
        self.keuze_t = 1.0
        self.tijd = 0.0
        self.actief_l = self.actief_r = 0.0
        self.feest = None
        self.deeltjes = c.Deeltjes()
        self.s_plop = [c.plop(h) for h in (0.9, 1.1, 1.3)]
        self.s_blip = c.blip(990)
        self.s_zoef = c.zoef()
        self.s_blij = c.blij_deuntje()

    def vrije_plek(self):
        """Zoek een plekje dat zo ver mogelijk van de andere stickers ligt."""
        beste, beste_afstand = None, -1
        for _ in range(30):
            x, y = random.uniform(110, W - 110), random.uniform(100, LADE_Y - 130)
            afstand = min((math.hypot(x - g.x, y - g.y) for g in self.geplakt), default=9999)
            if afstand > beste_afstand:
                beste, beste_afstand = (x, y), afstand
        return beste

    def plak(self):
        x, y = self.vrije_plek()
        g = Geplakt(self.keuze, x, y, random.uniform(0.85, 1.15), random.uniform(-20, 20))
        self.geplakt.append(g)
        random.choice(self.s_plop).play()
        self.deeltjes.burst(x, y, 20, soort="ster", snelheid=380, grootte=(6, 12))
        if len(self.geplakt) >= PER_BLAD:
            self.feest = 0.0
            self.s_blij.play()

    def nieuw_blad(self):
        for g in self.geplakt:
            g.vlucht = (random.uniform(-500, 500), random.uniform(-700, -300), random.uniform(-400, 400))
            g.gebakken = False
        self.vliegend = self.geplakt
        self.geplakt = []
        self.blad = (self.blad + 1) % len(self.achtergronden)
        self.blad_img = self.achtergronden[self.blad].copy()
        self.s_zoef.play()

    def handle(self, e):
        k = c.toets(e)
        if k is None or self.feest is not None:
            return
        if k == "links":
            self.keuze = (self.keuze + 1) % len(self.stickers)
            self.keuze_t = 0.0
            self.actief_l = 1.0
            self.s_blip.play()
        elif k == "rechts":
            self.actief_r = 1.0
            self.plak()
        else:
            self.keuze = random.randrange(len(self.stickers))
            self.plak()

    def update(self, dt):
        self.tijd += dt
        self.keuze_t = min(1.0, self.keuze_t + dt / 0.3)
        self.actief_l = max(0.0, self.actief_l - dt * 4)
        self.actief_r = max(0.0, self.actief_r - dt * 4)
        for g in self.geplakt:
            g.t += dt
        for g in self.vliegend:
            vx, vy, vr = g.vlucht
            vy += 1500 * dt
            g.vlucht = (vx, vy, vr)
            g.x += vx * dt
            g.y += vy * dt
            g.hoek += vr * dt
        self.vliegend = [g for g in self.vliegend if g.y < H + 200]
        if self.feest is not None:
            self.feest += dt
            if random.random() < dt * 8:
                self.deeltjes.burst(random.uniform(100, W - 100), random.uniform(50, 300), 25)
            if self.feest > 2.5:
                self.feest = None
                self.nieuw_blad()
        self.deeltjes.update(dt)

    def draw(self, s):
        # stickers die klaar zijn met oppoppen gaan vast in het blad-plaatje,
        # maar alleen als er geen nog-poppende sticker onder zou komen
        for g in self.geplakt:
            if g.gebakken:
                continue
            if not g.klaar():
                break
            g.draw(self.blad_img, self.stickers)
            g.gebakken = True
        s.blit(self.blad_img, (0, 0))
        for g in self.geplakt:
            if not g.gebakken:
                g.draw(s, self.stickers)
        for g in self.vliegend:
            g.draw(s, self.stickers)

        # lade met de stickers
        s.blit(self.lade, (10, H - 145))
        n = len(self.duimpjes)
        stap = (W - 340) / n
        for i, d in enumerate(self.duimpjes):
            x = 170 + stap * (i + 0.5)
            if i == self.keuze:
                k = c.ease_out_back(self.keuze_t)
                pygame.draw.circle(s, (255, 230, 120), (x, LADE_Y), 52)
                big = pygame.transform.rotozoom(d, math.sin(self.tijd * 4) * 8, 1.0 + 0.35 * k)
                s.blit(big, big.get_rect(center=(x, LADE_Y - 8 * k)))
            else:
                s.blit(d, d.get_rect(center=(x, LADE_Y)))

        c.pijl(s, (85, LADE_Y), -1, 46, actief=self.actief_l)
        c.pijl(s, (W - 85, LADE_Y), 1, 46, actief=self.actief_r)

        # tellertje: hoeveel stickers nog tot het blad vol is
        for i in range(PER_BLAD):
            x = W // 2 - (PER_BLAD - 1) * 18 + i * 36
            vol = i < len(self.geplakt)
            pygame.draw.polygon(s, (255, 210, 50) if vol else (255, 255, 255),
                                c.sterpunten(x, 30, 15, 7))
            pygame.draw.polygon(s, c.ZWART, c.sterpunten(x, 30, 15, 7), 2)

        self.deeltjes.draw(s)
        if self.feest is not None:
            c.tekst(s, "Mooi!", int(150 * c.ease_out_back(self.feest / 0.4)) or 1, (255, 220, 80),
                    (W // 2, H // 2 - 60), dikte=5)


if __name__ == "__main__":
    c.los_starten(StickerSpel)
